export interface InfographicSlide {
  slide_number: number;
  headline: string;
  body_text: string;
  recommended_icon: string;
  slide_type?: string;
  visual_cue?: string;
  callout?: string;
  tags?: string[];
}

export interface MarketingKit {
  seo_title: string;
  seo_description: string;
  key_features: string[];
  infographics_slides: InfographicSlide[];
  seo_score?: number;
  keyword_density?: string;
  char_count?: number;
  brand_story?: string;
  marketplace_compliance?: string;
}

export type Marketplace = 'Amazon' | 'Ozon' | 'Wildberries' | 'Shopify';
export type ToneOfVoice = 'Premium & Luxury' | 'Selling & Energy' | 'Technical' | 'Minimalist';

export interface ProductFormData {
  title: string;
  features: string;
  marketplace: Marketplace;
  tone: ToneOfVoice;
  imageFileName: string;
  imageFileSize: string;
  imageDataUrl: string;
  imageDimensions: string;
  visualPreset?: string;
}
