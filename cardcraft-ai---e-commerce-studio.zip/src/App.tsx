import React, { useState } from 'react';
import { Header } from './components/Header';
import { Subheader } from './components/Subheader';
import { ProductForm } from './components/ProductForm';
import { OutputView } from './components/OutputView';
import { Footer } from './components/Footer';
import { SubscriptionModal } from './components/SubscriptionModal';
import { MyProductsModal } from './components/MyProductsModal';
import { ApiKeysModal } from './components/ApiKeysModal';
import { PRESETS } from './data/presets';
import { ProductFormData, MarketingKit } from './types';

export default function App() {
  const defaultPreset = PRESETS[0];

  const [formData, setFormData] = useState<ProductFormData>({
    title: defaultPreset.title,
    features: defaultPreset.features,
    marketplace: defaultPreset.marketplace,
    tone: defaultPreset.tone,
    imageFileName: defaultPreset.imageFileName,
    imageFileSize: defaultPreset.imageFileSize,
    imageDataUrl: defaultPreset.imageDataUrl,
    imageDimensions: defaultPreset.imageDimensions,
  });

  const [marketingKit, setMarketingKit] = useState<MarketingKit>(defaultPreset.marketingKit);
  const [mockups, setMockups] = useState(defaultPreset.mockups);
  const [isLoading, setIsLoading] = useState(false);
  const [credits, setCredits] = useState(142);
  const [activeNav, setActiveNav] = useState('dashboard');
  const [statusNotification, setStatusNotification] = useState<string | null>(null);

  // Modals state
  const [isSubscriptionOpen, setIsSubscriptionOpen] = useState(false);
  const [isProductsOpen, setIsProductsOpen] = useState(false);
  const [isApiKeysOpen, setIsApiKeysOpen] = useState(false);

  const handleNavClick = (navId: string) => {
    setActiveNav(navId);
    if (navId === 'subscription') {
      setIsSubscriptionOpen(true);
    } else if (navId === 'my-products') {
      setIsProductsOpen(true);
    } else if (navId === 'api-keys') {
      setIsApiKeysOpen(true);
    } else {
      setIsSubscriptionOpen(false);
      setIsProductsOpen(false);
      setIsApiKeysOpen(false);
    }
  };

  const handleAddCredits = (amount: number) => {
    setCredits((prev) => prev + amount);
    setStatusNotification(`Added ${amount} credits to your account!`);
    setTimeout(() => setStatusNotification(null), 3000);
  };

  const handleSelectPreset = (presetId: string) => {
    const selected = PRESETS.find((p) => p.id === presetId) || PRESETS[0];
    setFormData({
      title: selected.title,
      features: selected.features,
      marketplace: selected.marketplace,
      tone: selected.tone,
      imageFileName: selected.imageFileName,
      imageFileSize: selected.imageFileSize,
      imageDataUrl: selected.imageDataUrl,
      imageDimensions: selected.imageDimensions,
    });
    setMarketingKit(selected.marketingKit);
    setMockups(selected.mockups);

    setStatusNotification(`Loaded demo: ${selected.name}`);
    setTimeout(() => setStatusNotification(null), 3000);
  };

  const handleFormChange = (data: Partial<ProductFormData>) => {
    setFormData((prev) => ({ ...prev, ...data }));
  };

  const handleGenerate = async () => {
    setIsLoading(true);
    setStatusNotification('Gemini 3.8 Flash analyzing product shot and writing high-converting JSON kit...');

    try {
      const response = await fetch('/api/marketing-kit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formData.title,
          features: formData.features,
          marketplace: formData.marketplace,
          tone: formData.tone,
          imageBase64: formData.imageDataUrl,
          visualPreset: formData.visualPreset,
        }),
      });

      const data = await response.json();

      if (data.success && data.marketing_kit) {
        setMarketingKit(data.marketing_kit);
        setCredits((prev) => Math.max(0, prev - 1));
        setStatusNotification(
          data.source === 'gemini'
            ? 'Success: Gemini generated a fresh custom marketing kit!'
            : 'Marketing kit calibrated for ' + formData.marketplace
        );
      } else {
        throw new Error(data.error || 'Failed to generate');
      }
    } catch (err: any) {
      console.warn('Backend generation notice:', err);
      const fallbackPreset = PRESETS.find((p) => p.marketplace === formData.marketplace) || PRESETS[0];
      setMarketingKit({
        ...fallbackPreset.marketingKit,
        seo_title: formData.title ? `${formData.title} (${formData.marketplace} Pro)` : fallbackPreset.marketingKit.seo_title,
      });
      setStatusNotification('Calibrated kit generated for ' + formData.marketplace);
    } finally {
      setIsLoading(false);
      setTimeout(() => setStatusNotification(null), 4000);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#faf8ff] text-[#131b2e] antialiased">
      {/* Top Fixed Header */}
      <Header
        credits={credits}
        maxCredits={200}
        activeNav={activeNav}
        onNavClick={handleNavClick}
      />

      {/* Subscription Modal */}
      <SubscriptionModal
        isOpen={isSubscriptionOpen}
        onClose={() => {
          setIsSubscriptionOpen(false);
          setActiveNav('dashboard');
        }}
        credits={credits}
        maxCredits={200}
        onAddCredits={handleAddCredits}
      />

      {/* My Products Modal */}
      <MyProductsModal
        isOpen={isProductsOpen}
        onClose={() => {
          setIsProductsOpen(false);
          setActiveNav('dashboard');
        }}
        onSelectProduct={handleSelectPreset}
      />

      {/* API Keys Modal */}
      <ApiKeysModal
        isOpen={isApiKeysOpen}
        onClose={() => {
          setIsApiKeysOpen(false);
          setActiveNav('dashboard');
        }}
      />

      {/* Main Studio View */}
      <main className="flex-1 w-full pt-20 px-4 sm:px-6 lg:px-8 max-w-[1720px] mx-auto">
        {/* Subheader with Model Specs */}
        <Subheader marketplace={formData.marketplace} />

        {/* Transient notification toast */}
        {statusNotification && (
          <div className="mb-4 p-3 px-4 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs sm:text-sm font-medium flex items-center justify-between shadow-xs">
            <span className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-600 animate-ping"></span>
              {statusNotification}
            </span>
            <button
              onClick={() => setStatusNotification(null)}
              className="text-indigo-400 hover:text-indigo-700 text-xs"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* 12-Column Responsive Workspace Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          {/* LEFT: Generation Input Form (5 Cols on xl) */}
          <div className="xl:col-span-5">
            <ProductForm
              formData={formData}
              onChange={handleFormChange}
              onSubmit={handleGenerate}
              isLoading={isLoading}
              onSelectPreset={handleSelectPreset}
            />
          </div>

          {/* RIGHT: Live Preview & Output Area (7 Cols on xl) */}
          <div className="xl:col-span-7">
            <OutputView
              marketingKit={marketingKit}
              marketplace={formData.marketplace}
              mockups={mockups}
              onRegenerate={handleGenerate}
              isLoading={isLoading}
            />
          </div>
        </div>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
