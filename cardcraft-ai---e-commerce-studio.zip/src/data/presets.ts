import { MarketingKit, Marketplace, ToneOfVoice } from '../types';

export interface ProductPreset {
  id: string;
  name: string;
  marketplace: Marketplace;
  tone: ToneOfVoice;
  title: string;
  features: string;
  imageFileName: string;
  imageFileSize: string;
  imageDataUrl: string;
  imageDimensions: string;
  mockups: {
    title: string;
    label: string;
    imageUrl: string;
    prompt: string;
  }[];
  marketingKit: MarketingKit;
}

export const PRESETS: ProductPreset[] = [
  {
    id: 'nomad-espresso',
    name: 'NomadBrew Pro (Espresso Maker)',
    marketplace: 'Amazon',
    tone: 'Premium & Luxury',
    title: 'NomadBrew Pro - Portable Espresso Coffee Maker (18-Bar Manual Pump)',
    features: `• 18-bar high pressure manual extraction for rich golden crema
• Compact 380g lightweight aeronautic aluminum & walnut wood handle
• Compatible with ground coffee and Nespresso original pods
• No battery or electricity required - perfect for camping & travel
• Food-grade stainless steel chamber, dishwasher-safe components`,
    imageFileName: 'espresso_hero_clean.png',
    imageFileSize: '2.4 MB',
    imageDimensions: '4096 × 4096px',
    imageDataUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA0oCADQ8CSYJuO7rqhrGgD3av2pfk2LW9Qh-lk7UtwEC5VBMfgVRrl0k3fi_aJkuvAcYzc5ru4EM2u7n8LT7Mz1FZt8k6V8uUs90f1CSUAIkCe7E7FZb5dAPSyp1vdsPalonNUa7fOulpotEIlLr-ZBWFCc1EDAe3E7NOBvzylRJPlYp_WttUCYLGhuwwFThaucqz_3_s2-VlyidRZGf6p767bRrWk2APfAsBCieZ4pAiW6tjiVS46',
    mockups: [
      {
        title: 'Kitchen Counter Hero',
        label: 'Card 1 • 1:1',
        imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBD-zXFhQ06YwAzEEznZtxTMZX_ovgU1pR4AvSG_43Uvui3cRe7keQFzBI_7hMum9e3a8rvBSvKKd9F1UcKBDU7s7dn2xfh57SPc_D4hQMTupSJ5adRD0h7LaJGFYqIuaEelQvcM4sEafBn3ZNjaCS3-3M6-l9qh6acYsOYztLjECZI_-N5xB5VV2oa5Rev6RCLGgIJ-IFe3bH4S9APs9Rk7MQ0iIRx13gzqcIJ6u_ST8lCze6AJmhk',
        prompt: 'Commercial e-commerce studio hero shot of a matte black portable manual espresso maker on a polished white marble kitchen countertop beside a ceramic cup filled with thick golden espresso crema, gentle morning sunlight.'
      },
      {
        title: 'Pressure Gauge Detail',
        label: 'Card 2 • Macro',
        imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDCtUhTMv9WL5CgkhiXblVxGSess27Y8rutKXEXZI0o6myjB7J73vhsyaJlefhM1-9Mjv7vAUgMpzHAAn_cuzN9fsfaveBqEx6d3CW67AEq8Ce62lmDfeMbNfXQ6UVcLOPMEmcuJ3D_oDvq8q2jUbQtYlnu0TaeY-EUfWdYI0nEYVTH4vKazK98oraVIHSTGcWB8PjmUuCt7oHdk-Wyn7Mp4_EcNxvArxtjEv8-OadP30wa_4fgrpyb',
        prompt: 'Close up product photography of an ergonomic walnut wood lever handle connected to a precision CNC-machined matte black manual coffee pump with a visible circular pressure gauge needle pointing at 18 bars.'
      },
      {
        title: 'Outdoor Camp Context',
        label: 'Card 3 • Lifestyle',
        imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAG0q5unq8vcGDnvirIACrAXFWeodcwBMG1DBpBB_fQ9U_cjDdajCyKBORtWn8Ksb3Rnq3QKYQuf5wAHHMEocnb03txMp5cYuTl3Ac5hWLYjmoSvOrOn81GfgrF6LrZo6IaaxI-U8lUj11ediCwRerLv1XOs2M3AWT-BiJ9HNid42DTvzjFu86fZTybwdwottIIryZDZULEiRtepCS9rHMynw5SKRFGFB3eDSlVge-YXkn22NCMOIHz',
        prompt: 'Outdoor lifestyle product shot of a traveler brewing fresh espresso with a sleek portable espresso press on a rustic cedar wood camping table overlooking a misty pine forest mountain ridge at sunrise.'
      }
    ],
    marketingKit: {
      seo_title: "NomadBrew Pro Portable Espresso Machine – 18 Bar Handheld Coffee Maker with Real Crema, Compatible with Ground Coffee & Pods, Manual Travel Coffee Press for Camping, Office, Hiking",
      seo_description: "Uncompromising Espresso Craftsmanship On The Go.\n\nEngineered for coffee purists who refuse to drink subpar instant packets while exploring alpine summits or navigating hotel rooms. The NomadBrew Pro packs the power of commercial counter espresso equipment into an ultra-portable cylindrical form factor.\n\nBy engineering a dual-spring hydraulic pump, manual strokes build progressive pressure up to a certified 18 bars. The result? Pure espresso emulsion, silky mouthfeel, and genuine aroma notes extracted at peak temp stability.",
      key_features: [
        "TRUE 18-BAR EXTRACTION: Delivers authentic rich Italian espresso with velvety thick golden crema anytime, anywhere. Equipped with precision pneumatic piston seals.",
        "DUAL-BREW VERSATILITY: Effortlessly swap between fine ground espresso roast and standard NS capsules with the included modular dual-basket adapter.",
        "ULTRA-LIGHTWEIGHT TRAVEL DESIGN: Weighs only 0.85 lbs (385g) with an ergonomic real walnut timber lever handle that folds flush against the body.",
        "NO ELECTRICITY NEEDED: Fully manual hydraulic piston system—zero charging cords, internal lithium batteries, or wall plugs required.",
        "ECO-FRIENDLY & EASY CLEAN: Precision food-grade 304 stainless steel interior rinses spotless under running water in under 10 seconds."
      ],
      infographics_slides: [
        {
          slide_number: 1,
          headline: "Barista Espresso Anywhere On Earth",
          body_text: "Certified 18-bar manual hydraulic pump produces thick, rich golden crema on demand.",
          recommended_icon: "coffee",
          slide_type: "HERO HOOK",
          visual_cue: "High-speed macro capture of rich espresso streaming into ceramic cup with golden crema swirl.",
          callout: "Overlay: Certified 18-Bar Seal",
          tags: ["#18BarPump", "#RealCrema", "#BaristaAnywhere"]
        },
        {
          slide_number: 2,
          headline: "Precision Crafted Aerospace Components",
          body_text: "CNC anodized aluminum body with food-safe 304 stainless steel core and walnut lever.",
          recommended_icon: "settings",
          slide_type: "EXPLODED ANATOMY",
          visual_cue: "Floating parts explosion with callout pointers highlighting 304 steel & walnut lever.",
          callout: "Callout: Integrated 0-20 Bar Gauge",
          tags: ["#CNCAluminum", "#SolidWalnut", "#304Stainless"]
        },
        {
          slide_number: 3,
          headline: "Fresh Espresso In 30 Seconds",
          body_text: "Add grounds or pods, pour hot water, and pump gently for instant barista quality.",
          recommended_icon: "timer",
          slide_type: "3-STEP WORKFLOW",
          visual_cue: "Step 1: Fill Pod/Grinds • Step 2: Pour 90°C Water • Step 3: Gentle Hydraulic Pumping.",
          callout: "Metric: 12-15 Pumps / Shot",
          tags: ["#ZeroEffort", "#NoBatteries", "#QuickRinse"]
        },
        {
          slide_number: 4,
          headline: "Smaller Than A Water Bottle",
          body_text: "Weighs only 385g with a collapsible lever designed to slip into any backpack pocket.",
          recommended_icon: "backpack",
          slide_type: "SIZE COMPARISON",
          visual_cue: "Direct visual scale next to an iPhone 15 Pro and everyday carry travel backpack pocket.",
          callout: "Comparison: 65% lighter than peers",
          tags: ["#385Grams", "#BackpackReady", "#UltraSlim"]
        }
      ],
      seo_score: 96,
      keyword_density: "Optimal (2.8%)",
      char_count: 2840,
      brand_story: "Engineered for coffee purists who refuse to drink subpar instant packets while exploring alpine summits or navigating hotel rooms. The NomadBrew Pro packs the power of commercial counter espresso equipment into an ultra-portable cylindrical form factor.\n\nBy engineering a dual-spring hydraulic pump, manual strokes build progressive pressure up to a certified 18 bars. The result? Pure espresso emulsion, silky mouthfeel, and genuine aroma notes extracted at peak temp stability.",
      marketplace_compliance: "0 policy warnings detected (Amazon Brand Registry Safe)"
    }
  },
  {
    id: 'ozon-sample',
    name: 'NomadBrew Pro (Ozon Russia)',
    marketplace: 'Ozon',
    tone: 'Selling & Energy',
    title: 'Кофемашина портативная ручная NomadBrew Pro 18 Бар – Ручная кофеварка эспрессо для молотого кофе и капсул',
    features: `• Сертифицированное давление 18 бар для плотной золотистой пенки crema
• Совместимость 2-в-1: молотый кофе любого помола + капсулы Nespresso
• Корпус из авиационного анодированного алюминия и рукоять из массива ореха
• Вес 385 грамм, компактнее полулитровой термокружки
• Не требует батареек или зарядки — 100% автономная гидравлика`,
    imageFileName: 'espresso_hero_clean.png',
    imageFileSize: '2.4 MB',
    imageDimensions: '4096 × 4096px',
    imageDataUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA0oCADQ8CSYJuO7rqhrGgD3av2pfk2LW9Qh-lk7UtwEC5VBMfgVRrl0k3fi_aJkuvAcYzc5ru4EM2u7n8LT7Mz1FZt8k6V8uUs90f1CSUAIkCe7E7FZb5dAPSyp1vdsPalonNUa7fOulpotEIlLr-ZBWFCc1EDAe3E7NOBvzylRJPlYp_WttUCYLGhuwwFThaucqz_3_s2-VlyidRZGf6p767bRrWk2APfAsBCieZ4pAiW6tjiVS46',
    mockups: [
      {
        title: 'Hero Студия',
        label: 'Слайд 1 • Главная',
        imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBD-zXFhQ06YwAzEEznZtxTMZX_ovgU1pR4AvSG_43Uvui3cRe7keQFzBI_7hMum9e3a8rvBSvKKd9F1UcKBDU7s7dn2xfh57SPc_D4hQMTupSJ5adRD0h7LaJGFYqIuaEelQvcM4sEafBn3ZNjaCS3-3M6-l9qh6acYsOYztLjECZI_-N5xB5VV2oa5Rev6RCLGgIJ-IFe3bH4S9APs9Rk7MQ0iIRx13gzqcIJ6u_ST8lCze6AJmhk',
        prompt: 'Студийный снимок портативной ручной кофеварки на мраморной столешнице с чашкой свежего эспрессо.'
      },
      {
        title: 'Манометр и рычаг',
        label: 'Слайд 2 • Детали',
        imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDCtUhTMv9WL5CgkhiXblVxGSess27Y8rutKXEXZI0o6myjB7J73vhsyaJlefhM1-9Mjv7vAUgMpzHAAn_cuzN9fsfaveBqEx6d3CW67AEq8Ce62lmDfeMbNfXQ6UVcLOPMEmcuJ3D_oDvq8q2jUbQtYlnu0TaeY-EUfWdYI0nEYVTH4vKazK98oraVIHSTGcWB8PjmUuCt7oHdk-Wyn7Mp4_EcNxvArxtjEv8-OadP30wa_4fgrpyb',
        prompt: 'Макро детализация рычага из натурального дерева ореха и манометра давления.'
      },
      {
        title: 'Поход и природа',
        label: 'Слайд 3 • Лайфстайл',
        imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAG0q5unq8vcGDnvirIACrAXFWeodcwBMG1DBpBB_fQ9U_cjDdajCyKBORtWn8Ksb3Rnq3QKYQuf5wAHHMEocnb03txMp5cYuTl3Ac5hWLYjmoSvOrOn81GfgrF6LrZo6IaaxI-U8lUj11ediCwRerLv1XOs2M3AWT-BiJ9HNid42DTvzjFu86fZTybwdwottIIryZDZULEiRtepCS9rHMynw5SKRFGFB3eDSlVge-YXkn22NCMOIHz',
        prompt: 'Приготовление кофе в походе на деревянном столе с панорамным видом на горы.'
      }
    ],
    marketingKit: {
      seo_title: "Кофемашина портативная ручная NomadBrew Pro 18 Бар – Ручная кофеварка эспрессо для молотого кофе и капсул, дорожный пресс для кемпинга, авто и офиса",
      seo_description: "Настоящий итальянский эспрессо с густой золотистой пенкой crema везде, где бы вы ни находились! NomadBrew Pro — это ультрапортативная ручная кофемашина премиум-класса с гидравлической помпой 18 бар.\n\nПреимущества:\n• Настоящее давление 18 бар без батареек и проводов\n• Универсальность: 2 в 1 (молотый кофе любого помола + капсулы Nespresso)\n• Рукоятка из натурального ореха и корпус из авиационного алюминия\n• Вес всего 385 грамм — помещается в карман рюкзака или подстаканник\n• Быстрая промывка за 10 секунд без моющих средств",
      key_features: [
        "ДАВЛЕНИЕ 18 БАР: Ручная гидравлическая помпа создает эталонное давление для экстракции плотного эспрессо с насыщенным вкусом.",
        "ФОРМАТ 2 В 1: В комплекте сменные фильтры для свежемолотого кофе и оригинальных капсул формата NS.",
        "ПРЕМИУМ МАТЕРИАЛЫ: Корпус из анодированного алюминия, внутренняя колба из пищевой стали 304 и отделка натуральным орехом.",
        "АВТОНОМНОСТЬ 100%: Никаких аккумуляторов, кабелей или газа — только горячая вода и несколько нажатий.",
        "КОМПАКТНЫЙ ВЕС 385 Г: Идеальный спутник в походах, автомобильных путешествиях, командировках и на пикнике."
      ],
      infographics_slides: [
        {
          slide_number: 1,
          headline: "Бариста Качество Везде",
          body_text: "Густая пенка crema и насыщенный вкус благодаря сертифицированному давлению 18 бар.",
          recommended_icon: "coffee",
          slide_type: "HERO HOOK",
          visual_cue: "Макросъемка струи эспрессо, стекающей в керамическую чашку с плотной пенкой.",
          callout: "Гарантия давления 18 Бар",
          tags: ["#ЭспрессоВезде", "#НастоящаяCrema", "#OzonТоп"]
        },
        {
          slide_number: 2,
          headline: "Авиационный Алюминий И Орех",
          body_text: "Детали из стали 304, прочный матовый корпус и эргономичный складной рычаг.",
          recommended_icon: "shield",
          slide_type: "EXPLODED ANATOMY",
          visual_cue: "Взрыв-схема компонентов с указанием стали 304 и ручки из массива ореха.",
          callout: "Манометр 0-20 Бар",
          tags: ["#ПремиумКачество", "#Сталь304", "#Орех"]
        },
        {
          slide_number: 3,
          headline: "Чашка Кофе За 30 Секунд",
          body_text: "Засыпьте кофе или вставьте капсулу, добавьте горячую воду и нажмите рычаг.",
          recommended_icon: "bolt",
          slide_type: "3-STEP WORKFLOW",
          visual_cue: "Пошаговая наглядная инструкция: 1 Кофе, 2 Вода, 3 Нажатие.",
          callout: "Всего 12 нажатий на порцию",
          tags: ["#ПростоИБыстро", "#БезБатареек", "#ЛегкоМыть"]
        },
        {
          slide_number: 4,
          headline: "Легче Бутылки Воды",
          body_text: "Весит всего 385 грамм и легко помещается в любой карман городского рюкзака.",
          recommended_icon: "feather",
          slide_type: "SIZE COMPARISON",
          visual_cue: "Сравнение габаритов со смартфоном и компактным термосом.",
          callout: "Вес всего 385 грамм",
          tags: ["#Компактность", "#ВДорогу", "#EDC"]
        }
      ],
      seo_score: 98,
      keyword_density: "Оптимальная (3.1%)",
      char_count: 2650,
      brand_story: "NomadBrew Pro создан для ценителей безупречного кофе, которые не готовы идти на компромиссы во время путешествий, восхождений или рабочих поездок. Компактность карманного аксессуара в сочетании с мощью профессиональной леверной группы.",
      marketplace_compliance: "Соответствует требованиям модерации Ozon (Rich-контент готов)"
    }
  },
  {
    id: 'wildberries-sample',
    name: 'NomadBrew Pro (Wildberries Russia)',
    marketplace: 'Wildberries',
    tone: 'Selling & Energy',
    title: 'Кофеварка ручная портативная NomadBrew Pro / мини кофемашина эспрессо походная для авто и туризма капсульная и молотый',
    features: `• 18 бар эталонного давления: настоящая плотная золотистая пенка крема
• Универсальность 2-в-1: подходит для молотого кофе и капсул Nespresso
• Рукоять из массива американского ореха, корпус из прочного алюминия
• Без аккумуляторов и батареек: надежная механическая помпа
• Вес 385 грамм, компактный размер — легко брать в дорогу и автомобиль`,
    imageFileName: 'espresso_hero_clean.png',
    imageFileSize: '2.4 MB',
    imageDimensions: '4096 × 4096px',
    imageDataUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA0oCADQ8CSYJuO7rqhrGgD3av2pfk2LW9Qh-lk7UtwEC5VBMfgVRrl0k3fi_aJkuvAcYzc5ru4EM2u7n8LT7Mz1FZt8k6V8uUs90f1CSUAIkCe7E7FZb5dAPSyp1vdsPalonNUa7fOulpotEIlLr-ZBWFCc1EDAe3E7NOBvzylRJPlYp_WttUCYLGhuwwFThaucqz_3_s2-VlyidRZGf6p767bRrWk2APfAsBCieZ4pAiW6tjiVS46',
    mockups: [
      {
        title: 'WB Hero Карточка',
        label: 'Карточка 1 • Обложка',
        imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBD-zXFhQ06YwAzEEznZtxTMZX_ovgU1pR4AvSG_43Uvui3cRe7keQFzBI_7hMum9e3a8rvBSvKKd9F1UcKBDU7s7dn2xfh57SPc_D4hQMTupSJ5adRD0h7LaJGFYqIuaEelQvcM4sEafBn3ZNjaCS3-3M6-l9qh6acYsOYztLjECZI_-N5xB5VV2oa5Rev6RCLGgIJ-IFe3bH4S9APs9Rk7MQ0iIRx13gzqcIJ6u_ST8lCze6AJmhk',
        prompt: 'Студийный снимок портативной ручной кофеварки на мраморной столешнице с чашкой свежего эспрессо.'
      },
      {
        title: 'Комплектация 2в1',
        label: 'Карточка 2 • Насадки',
        imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDCtUhTMv9WL5CgkhiXblVxGSess27Y8rutKXEXZI0o6myjB7J73vhsyaJlefhM1-9Mjv7vAUgMpzHAAn_cuzN9fsfaveBqEx6d3CW67AEq8Ce62lmDfeMbNfXQ6UVcLOPMEmcuJ3D_oDvq8q2jUbQtYlnu0TaeY-EUfWdYI0nEYVTH4vKazK98oraVIHSTGcWB8PjmUuCt7oHdk-Wyn7Mp4_EcNxvArxtjEv8-OadP30wa_4fgrpyb',
        prompt: 'Макро детализация рычага из натурального дерева ореха и манометра давления.'
      },
      {
        title: 'Походный формат',
        label: 'Карточка 3 • В дорогу',
        imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAG0q5unq8vcGDnvirIACrAXFWeodcwBMG1DBpBB_fQ9U_cjDdajCyKBORtWn8Ksb3Rnq3QKYQuf5wAHHMEocnb03txMp5cYuTl3Ac5hWLYjmoSvOrOn81GfgrF6LrZo6IaaxI-U8lUj11ediCwRerLv1XOs2M3AWT-BiJ9HNid42DTvzjFu86fZTybwdwottIIryZDZULEiRtepCS9rHMynw5SKRFGFB3eDSlVge-YXkn22NCMOIHz',
        prompt: 'Приготовление кофе в походе на деревянном столе с панорамным видом на горы.'
      }
    ],
    marketingKit: {
      seo_title: "Кофеварка ручная портативная NomadBrew Pro / мини кофемашина эспрессо походная для авто и туризма капсульная и молотый",
      seo_description: "Компактная ручная кофеварка эспрессо с давлением 18 бар. Подходит для молотого кофе и капсул Nespresso. Идеальный подарок автомобилисту, туристу, кофеману!\n\nГлавные плюсы:\n- Золотистая плотная пенка крема как из кофейни\n- Работает без розеток и батареек\n- Складная ручка из благородного ореха\n- Колба из нержавеющей стали 304\n- Комплект: адаптер под капсулы, мерная ложка, чехол для переноски",
      key_features: [
        "18 БАР ДАВЛЕНИЯ: Настоящая плотная крема и правильная экстракция кофейных масел в любых условиях.",
        "СОВМЕСТИМОСТЬ 2-В-1: Используйте любимый молотый кофе или удобные капсулы типа Nespresso Original.",
        "БЕЗ БАТАРЕЕК И ПРОВОДОВ: Полностью механическая надежная помпа — берите на дачу, охоту, рыбалку и в офис.",
        "КОМПАКТНЫЙ РАЗМЕР: Вес 385 г, высота 19 см — занимает минимум места в бардачке или рюкзаке.",
        "ПИЩЕВАЯ СТАЛЬ 304: Безопасные материалы без постороннего запаха пластика, простая мойка водой."
      ],
      infographics_slides: [
        {
          slide_number: 1,
          headline: "Кофе Как Из Кофейни",
          body_text: "Густая золотая пенка крема и глубокий аромат благодаря давлению 18 бар.",
          recommended_icon: "coffee",
          slide_type: "HERO HOOK",
          visual_cue: "Крупный план льющегося эспрессо в стильную чашку на природе.",
          callout: "Хит продаж WB",
          tags: ["#Вайлдберриз", "#Кофемашина", "#Подарок"]
        },
        {
          slide_number: 2,
          headline: "Под Молотый И Капсулы",
          body_text: "Универсальный переходник в комплекте для максимального удобства.",
          recommended_icon: "layers",
          slide_type: "VERSATILITY",
          visual_cue: "Демонстрация двух корзин: под капсулу и под свежий помол.",
          callout: "Адаптеры в комплекте",
          tags: ["#2в1", "#Капсулы", "#МолотыйКофе"]
        },
        {
          slide_number: 3,
          headline: "Готово За 30 Секунд",
          body_text: "Добавьте кипяток, сделайте несколько мягких нажатий и наслаждайтесь.",
          recommended_icon: "timer",
          slide_type: "HOW TO USE",
          visual_cue: "Простая пошаговая инфографика в 3 простых шага.",
          callout: "Без батареек и проводов",
          tags: ["#ЛегкоПриготовить", "#ВМашину", "#Туризм"]
        },
        {
          slide_number: 4,
          headline: "Компактный И Легкий 385г",
          body_text: "Меньше термокружки. Прочный алюминиевый корпус не боится падений.",
          recommended_icon: "package",
          slide_type: "SIZE",
          visual_cue: "Фотография в руке и рядом с дорожным рюкзаком.",
          callout: "Чехол в комплекте",
          tags: ["#Компактная", "#ВПоход", "#ПодарокМужчине"]
        }
      ],
      seo_score: 97,
      keyword_density: "Оптимальная (3.4%)",
      char_count: 2420,
      brand_story: "Подарите себе свободу пить эталонный эспрессо в автомобиле, в горах или в отеле. NomadBrew Pro объединяет эстетику итальянского дизайна и швейцарскую надежность механики.",
      marketplace_compliance: "SEO-оптимизировано под поисковые алгоритмы Wildberries"
    }
  },
  {
    id: 'shopify-sample',
    name: 'NomadBrew Pro (Shopify D2C)',
    marketplace: 'Shopify',
    tone: 'Premium & Luxury',
    title: 'NomadBrew Pro | Handheld 18-Bar Manual Espresso Maker — Dual Brew System for Artisanal Coffee Anywhere',
    features: `• Commercial Grade 18-Bar Extraction: Unlocks delicate terroir notes and dense crema
• Dual-Extraction System: Seamlessly accepts fresh specialty grind and NS pods
• Master Artisan Build: Sustainable solid American walnut handle, aerospace CNC body
• Completely Non-Electric: Zero battery degradation, cord-free freedom
• Zero Waste & Whisper Quiet: Engineered for a lifetime of serene morning rituals`,
    imageFileName: 'espresso_hero_clean.png',
    imageFileSize: '2.4 MB',
    imageDimensions: '4096 × 4096px',
    imageDataUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA0oCADQ8CSYJuO7rqhrGgD3av2pfk2LW9Qh-lk7UtwEC5VBMfgVRrl0k3fi_aJkuvAcYzc5ru4EM2u7n8LT7Mz1FZt8k6V8uUs90f1CSUAIkCe7E7FZb5dAPSyp1vdsPalonNUa7fOulpotEIlLr-ZBWFCc1EDAe3E7NOBvzylRJPlYp_WttUCYLGhuwwFThaucqz_3_s2-VlyidRZGf6p767bRrWk2APfAsBCieZ4pAiW6tjiVS46',
    mockups: [
      {
        title: 'Editorial Hero',
        label: 'Hero • 16:9 Banner',
        imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBD-zXFhQ06YwAzEEznZtxTMZX_ovgU1pR4AvSG_43Uvui3cRe7keQFzBI_7hMum9e3a8rvBSvKKd9F1UcKBDU7s7dn2xfh57SPc_D4hQMTupSJ5adRD0h7LaJGFYqIuaEelQvcM4sEafBn3ZNjaCS3-3M6-l9qh6acYsOYztLjECZI_-N5xB5VV2oa5Rev6RCLGgIJ-IFe3bH4S9APs9Rk7MQ0iIRx13gzqcIJ6u_ST8lCze6AJmhk',
        prompt: 'Commercial e-commerce studio hero shot of a matte black portable manual espresso maker on a polished white marble kitchen countertop.'
      },
      {
        title: 'Craftsmanship Detail',
        label: 'Macro • Precision',
        imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDCtUhTMv9WL5CgkhiXblVxGSess27Y8rutKXEXZI0o6myjB7J73vhsyaJlefhM1-9Mjv7vAUgMpzHAAn_cuzN9fsfaveBqEx6d3CW67AEq8Ce62lmDfeMbNfXQ6UVcLOPMEmcuJ3D_oDvq8q2jUbQtYlnu0TaeY-EUfWdYI0nEYVTH4vKazK98oraVIHSTGcWB8PjmUuCt7oHdk-Wyn7Mp4_EcNxvArxtjEv8-OadP30wa_4fgrpyb',
        prompt: 'Close up product photography of an ergonomic walnut wood lever handle connected to a precision CNC-machined manual pump.'
      },
      {
        title: 'Morning Ritual',
        label: 'Lifestyle • Mood',
        imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAG0q5unq8vcGDnvirIACrAXFWeodcwBMG1DBpBB_fQ9U_cjDdajCyKBORtWn8Ksb3Rnq3QKYQuf5wAHHMEocnb03txMp5cYuTl3Ac5hWLYjmoSvOrOn81GfgrF6LrZo6IaaxI-U8lUj11ediCwRerLv1XOs2M3AWT-BiJ9HNid42DTvzjFu86fZTybwdwottIIryZDZULEiRtepCS9rHMynw5SKRFGFB3eDSlVge-YXkn22NCMOIHz',
        prompt: 'Outdoor lifestyle product shot of a traveler brewing fresh espresso with a sleek portable espresso press overlooking a misty mountain ridge.'
      }
    ],
    marketingKit: {
      seo_title: "NomadBrew Pro | Handheld 18-Bar Manual Espresso Maker — Dual Brew System for Artisanal Coffee Anywhere",
      seo_description: "Elevate your daily brew ritual wherever adventure takes you. The NomadBrew Pro is a precision-engineered manual espresso press delivering certified 18-bar hydraulic extraction for silky crema and full-bodied single-origin profiles.\n\n• Commercial Grade 18-Bar Extraction: Unlocks delicate terroir notes and dense crema.\n• Dual-Extraction System: Seamlessly accepts fresh specialty grind and NS pods.\n• Master Artisan Build: Sustainable solid American walnut handle, aerospace CNC body.\n• Completely Non-Electric: Zero battery degradation, cord-free freedom.\n• Zero Waste & Whisper Quiet: Engineered for a lifetime of serene morning rituals.",
      key_features: [
        "CERTIFIED 18-BAR EXTRACTION: Experience velvety espresso emulsion rivaling commercial countertop E61 machines.",
        "ARTISAN HARDWOOD & CNC ALLOY: Crafted with heirloom walnut timber and matte scratch-resistant anodized aluminum.",
        "HYBRID GROUND & POD CHAMBER: Effortlessly switch between single-origin fine grounds and compostable pods.",
        "100% OFF-GRID FREEDOM: Silent manual hydraulic mechanism requires no electricity, chargers, or replacement batteries.",
        "EFFORTLESS DISASSEMBLY & RINSE: Dishwasher-safe food contact parts with medical-grade silicone seals."
      ],
      infographics_slides: [
        {
          slide_number: 1,
          headline: "Artisanal Crema Everywhere",
          body_text: "Precision 18-bar piston creates authentic microfoam crema without power cords.",
          recommended_icon: "award",
          slide_type: "HERO VALUE",
          visual_cue: "Warm kitchen editorial shot with golden sunrise light filtering across marble.",
          callout: "Crafted for Specialty Roasts",
          tags: ["#SpecialtyCoffee", "#D2CBrand", "#NomadBrew"]
        },
        {
          slide_number: 2,
          headline: "Sustainable Walnut Timber",
          body_text: "Heirloom American walnut meets aeronautic anodized alloy chassis.",
          recommended_icon: "shield",
          slide_type: "MATERIALS",
          visual_cue: "Close-up macro of natural wood grain and laser-etched graduation marks.",
          callout: "Lifetime Chassis Warranty",
          tags: ["#HeirloomCraft", "#AmericanWalnut", "#BuiltToLast"]
        },
        {
          slide_number: 3,
          headline: "Mindful Morning Ritual",
          body_text: "Quiet manual action brings peaceful intention to your dawn extraction.",
          recommended_icon: "heart",
          slide_type: "LIFESTYLE",
          visual_cue: "Steam gently curling from a warm ceramic demitasse cup.",
          callout: "Whisper-Quiet Operation",
          tags: ["#MorningRitual", "#MindfulCoffee", "#SlowLiving"]
        },
        {
          slide_number: 4,
          headline: "Zero Electrical Waste",
          body_text: "Zero lithium cells to degrade. 100% mechanical purity for decades of service.",
          recommended_icon: "compass",
          slide_type: "ECO ADVANTAGE",
          visual_cue: "Cutaway graphic of hydraulic springs and dual-gasket seals.",
          callout: "100% Carbon Offset Shipping",
          tags: ["#ZeroWaste", "#SustainableLiving", "#OffGrid"]
        }
      ],
      seo_score: 99,
      keyword_density: "Optimal (2.6%)",
      char_count: 2710,
      brand_story: "We founded NomadBrew with a single uncompromising mission: bring cafe-standard espresso extraction to the edge of the map. No cords, no planned obsolescence—just hydraulic precision and honest materials.",
      marketplace_compliance: "Shopify Store & Google Shopping Schema Ready"
    }
  }
];
