import React from 'react';
import { Zap, Bell, CheckCircle2 } from 'lucide-react';

interface HeaderProps {
  credits?: number;
  maxCredits?: number;
  activeNav?: string;
  onNavClick?: (nav: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  credits = 142,
  maxCredits = 200,
  activeNav = 'dashboard',
  onNavClick,
}) => {
  return (
    <header className="fixed top-0 left-0 right-0 w-full z-50 bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-[0_1px_6px_rgba(0,0,0,0.03)]">
      <div className="h-16 w-full px-4 sm:px-6 lg:px-8 max-w-[1720px] mx-auto flex items-center justify-between gap-4">
        {/* Left: Brand Logo & Navigation */}
        <div className="flex items-center gap-6 lg:gap-8">
          <div className="flex items-center gap-2.5 cursor-pointer select-none" onClick={() => onNavClick?.('dashboard')}>
            <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-sm shadow-indigo-600/30">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="3" y="4" width="18" height="16" rx="4" fill="currentColor" fillOpacity="0.2" />
                <path d="M7 8H17M7 12H14M7 16H11" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
                <circle cx="17" cy="8" r="1.8" fill="#38bdf8" />
              </svg>
            </div>
            <span className="font-display font-bold text-xl tracking-tight text-slate-900">
              CardCraft<span className="text-indigo-600">.ai</span>
            </span>
          </div>

          <nav className="flex items-center gap-1 bg-slate-100/85 p-1 rounded-xl border border-slate-200/80 shadow-xs overflow-x-auto max-w-[50vw] sm:max-w-none">
            {[
              { id: 'dashboard', label: 'Dashboard' },
              { id: 'my-products', label: 'My Products' },
              { id: 'subscription', label: 'Subscription', isPro: true },
              { id: 'api-keys', label: 'API Keys' },
            ].map((item) => {
              const isActive = activeNav === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavClick?.(item.id)}
                  className={`px-3 sm:px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-indigo-600 text-white font-semibold shadow-sm ring-1 ring-indigo-500/30'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
                  } ${item.id === 'subscription' ? 'font-semibold' : ''}`}
                >
                  <span>{item.label}</span>
                  {item.isPro && (
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full uppercase tracking-wider ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : 'bg-indigo-100 text-indigo-700'
                      }`}
                    >
                      Pro
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Right: Credits, Notifications, User Profile */}
        <div className="flex items-center gap-3 sm:gap-4">
          {/* Credits Counter Pill */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100/90 rounded-full border border-slate-200/80 text-xs sm:text-sm">
            <Zap className="w-4 h-4 text-indigo-600 fill-indigo-600" />
            <span className="font-semibold text-slate-900">{credits}</span>
            <span className="text-slate-400">/</span>
            <span className="text-slate-500 font-medium">{maxCredits} Credits</span>
          </div>

          {/* Notification Bell */}
          <button
            aria-label="Notifications"
            className="relative p-2 rounded-full text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
          </button>

          <div className="h-6 w-px bg-slate-200"></div>

          {/* User Profile */}
          <div className="flex items-center gap-2.5 pl-1">
            <div className="relative">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCdzSo7JlGeskSwLfve-YDZJIF7lPNbNOJMqKfzprPx-uZH-GmkNqXEKY2g-pJONEfUYlfAir8GUz9MVgJQfEPLM-JLZYKkjCiKM-ZDfmX80g9VRmrzp8Fgir7Th_4xmpIb6BYO5Exiebf4-V6qr92-BtZxCjExTLed_mMNNBA84ZSnDmddkjML9S9F2Xi0dPvRK9g7Iw_fKCCj8eK7ATm10_TOFducvvkWqBYroaOWTyR7BAQQXamm"
                alt="Elena Rostova"
                className="w-8 h-8 rounded-full object-cover border border-slate-200 shadow-sm"
              />
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></span>
            </div>
            <div className="hidden lg:flex flex-col items-start leading-tight">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-slate-900">Elena Rostova</span>
                <span className="inline-flex items-center px-1.5 py-0.2 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Pro Member
                </span>
              </div>
              <span className="text-[11px] text-slate-500">Merchant Tier</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
