import React from 'react';
import { Package, X, ArrowRight, ExternalLink, Sparkles } from 'lucide-react';
import { PRESETS } from '../data/presets';

interface MyProductsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (presetId: string) => void;
}

export const MyProductsModal: React.FC<MyProductsModalProps> = ({
  isOpen,
  onClose,
  onSelectProduct,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-5 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-sm">
              <Package className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg text-slate-900">
                My Products &amp; Catalog
              </h3>
              <p className="text-xs text-slate-500">
                Generated conversion kits saved in your workspace
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of Products */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {PRESETS.map((preset) => (
              <div
                key={preset.id}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:border-indigo-400 hover:shadow-md transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center gap-3 mb-3">
                    <img
                      src={preset.imageDataUrl}
                      alt={preset.name}
                      className="w-14 h-14 rounded-lg object-cover border border-slate-200 shadow-xs"
                    />
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                        {preset.marketplace}
                      </span>
                      <h4 className="font-bold text-sm text-slate-900 mt-1 line-clamp-1">
                        {preset.name}
                      </h4>
                      <p className="text-xs text-slate-500">
                        {preset.marketingKit.infographics_slides.length} Infographics • SEO {preset.marketingKit.seo_score || 96}/100
                      </p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600 line-clamp-2 mb-3">
                    {preset.marketingKit.seo_title}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    onSelectProduct(preset.id);
                    onClose();
                  }}
                  className="w-full py-2 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>Load in Card Studio</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-1" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <span>{PRESETS.length} products available in demo workspace</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
