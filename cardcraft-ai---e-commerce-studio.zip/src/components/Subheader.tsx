import React from 'react';
import { Sparkles, Gauge, Store, CheckCircle } from 'lucide-react';
import { Marketplace } from '../types';

interface SubheaderProps {
  marketplace: Marketplace;
}

export const Subheader: React.FC<SubheaderProps> = ({ marketplace }) => {
  const marketplaceSpecLabels: Record<Marketplace, string> = {
    Amazon: 'Amazon • US/EU Specs',
    Ozon: 'Ozon • RU E-com Specs',
    Wildberries: 'WB • CTR Optimized Specs',
    Shopify: 'Shopify • D2C Specs',
  };

  return (
    <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 mb-4 border-b border-slate-200/80">
      {/* Title & Model Pill */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded-lg bg-indigo-50 text-indigo-600 border border-indigo-100">
            <Sparkles className="w-5 h-5" />
          </div>
          <h1 className="font-display font-bold text-xl sm:text-2xl text-slate-900 tracking-tight">
            AI Card &amp; Infographics Studio
          </h1>
        </div>

        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs bg-slate-100 text-slate-700 font-medium border border-slate-200">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          Model: Gemini 3.8 Flash + Multi-Modal Vision
        </span>
      </div>

      {/* Metrics & Spec Indicators */}
      <div className="flex items-center flex-wrap gap-2 sm:gap-3 text-xs text-slate-600">
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200">
          <Gauge className="w-3.5 h-3.5 text-indigo-600" />
          <span>Avg. Gen Time:</span>
          <span className="font-semibold text-slate-900">~2.4s</span>
        </div>

        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200">
          <Store className="w-3.5 h-3.5 text-emerald-600" />
          <span>Target:</span>
          <span className="font-semibold text-slate-900">{marketplaceSpecLabels[marketplace]}</span>
        </div>

        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold">
          <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
          <span>A+ Standards Calibrated</span>
        </div>
      </div>
    </div>
  );
};
