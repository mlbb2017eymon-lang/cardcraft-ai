import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full bg-white border-t border-slate-200 mt-12 py-6">
      <div className="w-full px-4 sm:px-6 lg:px-8 max-w-[1720px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
        <div className="flex items-center gap-2">
          <span>&copy; 2026 CardCraft AI Inc. Precision E-commerce Asset Engine.</span>
        </div>
        <div className="flex items-center gap-6">
          <a href="#" className="hover:text-slate-900 transition-colors">
            Terms of Service
          </a>
          <a href="#" className="hover:text-slate-900 transition-colors">
            Privacy Policy
          </a>
          <a href="#" className="hover:text-slate-900 transition-colors">
            API Documentation
          </a>
          <a href="#" className="hover:text-slate-900 transition-colors">
            System Status
          </a>
        </div>
      </div>
    </footer>
  );
};
