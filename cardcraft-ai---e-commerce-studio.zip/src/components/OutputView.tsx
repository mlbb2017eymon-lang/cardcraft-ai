import React, { useState } from 'react';
import {
  CheckCircle2,
  View,
  FileText,
  Image as ImageIcon,
  Copy,
  Check,
  Download,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  Code,
  ArrowRight,
  ExternalLink,
  Coffee,
  Shield,
  Settings,
  Timer,
  Package,
  Layers,
  Award,
  Heart,
  Compass,
  Cpu,
  Feather,
  Zap,
} from 'lucide-react';
import { MarketingKit, Marketplace } from '../types';
import { copyToClipboard } from '../utils/clipboard';

interface OutputViewProps {
  marketingKit: MarketingKit;
  marketplace: Marketplace;
  mockups: {
    title: string;
    label: string;
    imageUrl: string;
    prompt: string;
  }[];
  onRegenerate: () => void;
  isLoading: boolean;
}

type TabType = 'seo' | 'slides' | 'json' | 'mockups';

export const OutputView: React.FC<OutputViewProps> = ({
  marketingKit,
  marketplace,
  mockups,
  onRegenerate,
  isLoading,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('seo');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const handleCopy = async (text: string, sectionId: string) => {
    await copyToClipboard(text);
    setCopiedSection(sectionId);
    setTimeout(() => {
      setCopiedSection(null);
    }, 2000);
  };

  const handleCopyCleanJson = async () => {
    // Return pure clean JSON as specified in user request
    const cleanOutput = {
      seo_title: marketingKit.seo_title,
      seo_description: marketingKit.seo_description,
      key_features: marketingKit.key_features,
      infographics_slides: marketingKit.infographics_slides.map((s) => ({
        slide_number: s.slide_number,
        headline: s.headline,
        body_text: s.body_text,
        recommended_icon: s.recommended_icon,
      })),
    };
    await copyToClipboard(JSON.stringify(cleanOutput, null, 2));
    setCopiedSection('clean-json');
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const handleDownloadJson = () => {
    const cleanOutput = {
      seo_title: marketingKit.seo_title,
      seo_description: marketingKit.seo_description,
      key_features: marketingKit.key_features,
      infographics_slides: marketingKit.infographics_slides.map((s) => ({
        slide_number: s.slide_number,
        headline: s.headline,
        body_text: s.body_text,
        recommended_icon: s.recommended_icon,
      })),
    };
    const blob = new Blob([JSON.stringify(cleanOutput, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cardcraft-marketing-kit-${marketplace.toLowerCase()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Icon mapping helper
  const renderIcon = (iconName: string) => {
    const iconLower = (iconName || '').toLowerCase();
    if (iconLower.includes('coffee')) return <Coffee className="w-4 h-4 text-indigo-600" />;
    if (iconLower.includes('shield')) return <Shield className="w-4 h-4 text-indigo-600" />;
    if (iconLower.includes('setting') || iconLower.includes('gear')) return <Settings className="w-4 h-4 text-indigo-600" />;
    if (iconLower.includes('time') || iconLower.includes('clock')) return <Timer className="w-4 h-4 text-indigo-600" />;
    if (iconLower.includes('backpack') || iconLower.includes('bag')) return <Package className="w-4 h-4 text-indigo-600" />;
    if (iconLower.includes('layer')) return <Layers className="w-4 h-4 text-indigo-600" />;
    if (iconLower.includes('award')) return <Award className="w-4 h-4 text-indigo-600" />;
    if (iconLower.includes('heart')) return <Heart className="w-4 h-4 text-indigo-600" />;
    if (iconLower.includes('compass')) return <Compass className="w-4 h-4 text-indigo-600" />;
    if (iconLower.includes('cpu')) return <Cpu className="w-4 h-4 text-indigo-600" />;
    if (iconLower.includes('feather')) return <Feather className="w-4 h-4 text-indigo-600" />;
    if (iconLower.includes('bolt')) return <Zap className="w-4 h-4 text-indigo-600" />;
    return <Sparkles className="w-4 h-4 text-indigo-600" />;
  };

  const wordCount = (marketingKit.seo_description || '').split(/\s+/).filter(Boolean).length;
  const charCount = (marketingKit.seo_description || '').length + (marketingKit.seo_title || '').length;

  return (
    <div className="bg-white rounded-xl border border-slate-200/90 shadow-sm overflow-hidden flex flex-col min-h-[780px]">
      {/* Tab Navigation Header Bar */}
      <div className="flex flex-wrap items-center justify-between p-3 sm:p-4 bg-slate-50/80 border-b border-slate-200 gap-3">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 bg-slate-200/70 p-1 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveTab('seo')}
            className={`px-3 sm:px-4 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'seo'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>SEO Copy</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 font-medium">
              {wordCount}w
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('slides')}
            className={`px-3 sm:px-4 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'slides'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-4 h-4 text-indigo-600" />
            <span>Infographics Plan</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-100 text-indigo-700 font-bold">
              {marketingKit.infographics_slides.length} Slides
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('json')}
            className={`px-3 sm:px-4 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'json'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Code className="w-4 h-4 text-amber-600" />
            <span>Clean JSON</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 font-bold">
              Schema Valid
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('mockups')}
            className={`px-3 sm:px-4 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'mockups'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ImageIcon className="w-4 h-4 text-slate-600" />
            <span>Mockups</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 font-medium">
              {mockups.length} Renders
            </span>
          </button>
        </div>

        {/* Action Buttons: Refresh, Export JSON */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onRegenerate}
            disabled={isLoading}
            title="Regenerate Kit"
            className="p-2 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors shadow-xs disabled:opacity-50"
          >
            <RotateCcw className={`w-4 h-4 ${isLoading ? 'animate-spin text-indigo-600' : ''}`} />
          </button>
          <button
            type="button"
            onClick={handleDownloadJson}
            className="px-3.5 py-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 text-slate-800 text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Export JSON</span>
          </button>
        </div>
      </div>

      {/* TAB 1: SEO COPY */}
      {activeTab === 'seo' && (
        <div className="p-5 sm:p-6 flex flex-col gap-6 flex-1">
          {/* SEO Metric Bar */}
          <div className="flex flex-wrap items-center justify-between p-3.5 rounded-xl bg-slate-50 border border-slate-200 gap-4">
            <div className="flex items-center gap-5 sm:gap-8">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <div>
                  <div className="text-[11px] text-slate-500 font-medium">SEO Score</div>
                  <div className="font-display font-bold text-sm sm:text-base text-slate-900">
                    {marketingKit.seo_score || 96}{' '}
                    <span className="font-normal text-xs text-slate-400">/ 100</span>
                  </div>
                </div>
              </div>

              <div className="h-8 w-px bg-slate-200"></div>

              <div>
                <div className="text-[11px] text-slate-500 font-medium">Length / Limit</div>
                <div className="text-xs sm:text-sm font-semibold text-slate-900">
                  {charCount}{' '}
                  <span className="text-xs text-slate-400 font-normal">/ 3,000 char</span>
                </div>
              </div>

              <div className="h-8 w-px bg-slate-200"></div>

              <div>
                <div className="text-[11px] text-slate-500 font-medium">Keyword Density</div>
                <div className="text-xs sm:text-sm font-bold text-emerald-600">
                  {marketingKit.keyword_density || 'Optimal (2.8%)'}
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() =>
                handleCopy(
                  `${marketingKit.seo_title}\n\n${marketingKit.key_features.join(
                    '\n'
                  )}\n\n${marketingKit.seo_description}`,
                  'copy-all'
                )
              }
              className="px-3.5 py-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 text-indigo-600 text-xs sm:text-sm font-semibold flex items-center gap-1.5 shadow-xs transition-all ml-auto"
            >
              {copiedSection === 'copy-all' ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-600">Copied All!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy All Text</span>
                </>
              )}
            </button>
          </div>

          {/* Optimized Marketplace Title Box */}
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
                Optimized Marketplace Title (High CTR)
              </label>
              <button
                type="button"
                onClick={() => handleCopy(marketingKit.seo_title, 'title')}
                className="text-slate-500 hover:text-indigo-600 text-xs flex items-center gap-1 transition-colors"
              >
                {copiedSection === 'title' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-600 font-semibold">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-sm font-medium text-slate-900 leading-relaxed">
              {marketingKit.seo_title}
            </div>
          </div>

          {/* 5-Point Highlights (Amazon / Marketplace Format) */}
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                Key Bulleted Highlights ({marketplace} 5-Point Format)
              </label>
              <button
                type="button"
                onClick={() => handleCopy(marketingKit.key_features.join('\n\n'), 'bullets')}
                className="text-slate-500 hover:text-indigo-600 text-xs flex items-center gap-1 transition-colors"
              >
                {copiedSection === 'bullets' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-600 font-semibold">Copied 5 Bullets!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy 5 Bullets</span>
                  </>
                )}
              </button>
            </div>

            <div className="space-y-2">
              {marketingKit.key_features.map((feature, idx) => {
                const colonIndex = feature.indexOf(':');
                const hasHeader = colonIndex !== -1 && colonIndex < 40;
                const header = hasHeader ? feature.substring(0, colonIndex + 1) : '';
                const body = hasHeader ? feature.substring(colonIndex + 1) : feature;

                return (
                  <div
                    key={idx}
                    className="p-3 px-4 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm leading-relaxed text-slate-800 flex items-start justify-between gap-3 group hover:bg-slate-100/70 transition-colors"
                  >
                    <div>
                      {hasHeader ? (
                        <>
                          <strong className="text-indigo-600 font-bold">{header}</strong>
                          <span>{body}</span>
                        </>
                      ) : (
                        <span>{feature}</span>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy(feature, `bullet-${idx}`)}
                      className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-indigo-600 shrink-0 p-1 transition-all"
                      title="Copy bullet"
                    >
                      {copiedSection === `bullet-${idx}` ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Structured Product Description / A+ Story */}
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                Structured Product Description &amp; A+ Story
              </label>
              <button
                type="button"
                onClick={() => handleCopy(marketingKit.seo_description, 'description')}
                className="text-slate-500 hover:text-indigo-600 text-xs flex items-center gap-1 transition-colors"
              >
                {copiedSection === 'description' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-600 font-semibold">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm text-slate-800 leading-relaxed whitespace-pre-line font-sans">
              {marketingKit.seo_description}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: INFOGRAPHICS PLAN */}
      {activeTab === 'slides' && (
        <div className="p-5 sm:p-6 flex flex-col gap-5 flex-1">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="font-display font-semibold text-base sm:text-lg text-slate-900">
                Visual Storyboard &amp; Tag Architecture
              </h3>
              <p className="text-xs text-slate-500">
                Recommended 4-slide sequence crafted specifically for e-commerce conversion optimization.
              </p>
            </div>
            <span className="text-xs bg-indigo-50 text-indigo-700 font-semibold px-2.5 py-1 rounded-lg border border-indigo-200">
              Format: 1:1 Square (2000 × 2000)
            </span>
          </div>

          {/* 4 Grid Slide Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {marketingKit.infographics_slides.map((slide) => (
              <div
                key={slide.slide_number}
                className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between group hover:border-indigo-200 hover:bg-slate-100/60 transition-all shadow-xs"
              >
                <div>
                  {/* Top Slide Header */}
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-md bg-indigo-600 text-white text-[11px] font-bold flex items-center justify-center">
                        {slide.slide_number}
                      </span>
                      <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                        SLIDE {slide.slide_number} • {slide.slide_type || `FRAME ${slide.slide_number}`}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] font-semibold text-slate-700 bg-white px-2 py-0.5 rounded-full border border-slate-200">
                      {renderIcon(slide.recommended_icon)}
                      <span className="capitalize">{slide.recommended_icon}</span>
                    </div>
                  </div>

                  {/* Slide Headline (Max 4 words) */}
                  <div className="font-display font-bold text-sm sm:text-base text-slate-900 mb-1 leading-snug">
                    “{slide.headline}”
                  </div>

                  {/* Body Text (Max 15 words) */}
                  <p className="text-xs text-slate-600 mb-3 leading-relaxed font-sans">
                    {slide.body_text}
                  </p>

                  {/* Visual Cue */}
                  {slide.visual_cue && (
                    <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-xs text-slate-700 mb-3 font-medium flex items-start gap-2">
                      <ImageIcon className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                      <span>{slide.visual_cue}</span>
                    </div>
                  )}

                  {/* Hashtags */}
                  {slide.tags && slide.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-3">
                      {slide.tags.map((tag, tagIdx) => (
                        <span
                          key={tagIdx}
                          className="text-[10px] font-medium bg-white border border-slate-200 px-2 py-0.5 rounded text-slate-700"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Bottom Callout Overlay */}
                {slide.callout && (
                  <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs text-indigo-600 font-semibold">
                    <span>{slide.callout}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-indigo-600 group-hover:translate-x-1 transition-transform" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: CLEAN VALID JSON (Directly satisfies user prompt requirement) */}
      {activeTab === 'json' && (
        <div className="p-5 sm:p-6 flex flex-col gap-4 flex-1">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-semibold text-base sm:text-lg text-slate-900">
                  Clean Valid Marketing Kit JSON
                </h3>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  <Check className="w-3 h-3" /> Validated JSON Only
                </span>
              </div>
              <p className="text-xs text-slate-500">
                100% compliant with the 4 requested keys: seo_title, seo_description, key_features, and infographics_slides.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCopyCleanJson}
                className="px-3.5 py-1.5 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 text-xs sm:text-sm font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
              >
                {copiedSection === 'clean-json' ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-300" />
                    <span>Copied Clean JSON!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copy Clean JSON</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleDownloadJson}
                className="px-3.5 py-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 text-slate-800 text-xs sm:text-sm font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
              >
                <Download className="w-4 h-4 text-slate-600" />
                <span>Download .JSON</span>
              </button>
            </div>
          </div>

          {/* JSON Code Viewer Container */}
          <div className="relative flex-1 bg-slate-950 rounded-xl p-4 border border-slate-800 text-slate-100 font-mono text-xs sm:text-sm overflow-x-auto shadow-inner">
            <pre className="whitespace-pre leading-relaxed text-emerald-400">
              {JSON.stringify(
                {
                  seo_title: marketingKit.seo_title,
                  seo_description: marketingKit.seo_description,
                  key_features: marketingKit.key_features,
                  infographics_slides: marketingKit.infographics_slides.map((s) => ({
                    slide_number: s.slide_number,
                    headline: s.headline,
                    body_text: s.body_text,
                    recommended_icon: s.recommended_icon,
                  })),
                },
                null,
                2
              )}
            </pre>
          </div>
        </div>
      )}

      {/* TAB 4: MOCKUPS */}
      {activeTab === 'mockups' && (
        <div className="p-5 sm:p-6 flex flex-col gap-5 flex-1">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="font-display font-semibold text-base sm:text-lg text-slate-900">
                Generated Visual Mockups
              </h3>
              <p className="text-xs text-slate-500">
                Calibrated photorealistic studio renders matching the visual style preset.
              </p>
            </div>
            <button
              type="button"
              onClick={onRegenerate}
              className="px-3.5 py-1.5 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 text-xs sm:text-sm font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Render Next Variant</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {mockups.map((mockup, idx) => (
              <div
                key={idx}
                className="rounded-xl overflow-hidden bg-slate-50 border border-slate-200 flex flex-col group hover:border-slate-300 transition-all shadow-xs"
              >
                <div className="relative aspect-square overflow-hidden bg-slate-200">
                  <img
                    src={mockup.imageUrl}
                    alt={mockup.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <span className="absolute top-2 left-2 bg-white/90 backdrop-blur-md text-[11px] px-2 py-0.5 rounded font-bold text-slate-800 border border-slate-200/60 shadow-xs">
                    {mockup.label}
                  </span>
                </div>
                <div className="p-3 flex items-center justify-between bg-white border-t border-slate-100">
                  <span className="text-xs font-bold text-slate-900">{mockup.title}</span>
                  <a
                    href={mockup.imageUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1"
                  >
                    <span>Inspect</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Output Bottom Sticky Status Footer */}
      <div className="mt-auto p-3.5 sm:p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
        <div className="flex items-center gap-2 font-medium">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>
            Compliance Check:{' '}
            <strong className="text-slate-700">
              {marketingKit.marketplace_compliance || `0 policy warnings detected (${marketplace} Calibrated)`}
            </strong>
          </span>
        </div>
        <div className="flex items-center gap-1 font-mono text-[11px]">
          <span>Session:</span>
          <span className="bg-slate-200/80 px-1.5 py-0.5 rounded text-slate-800 font-semibold">
            cc-gen-8491x
          </span>
        </div>
      </div>
    </div>
  );
};
