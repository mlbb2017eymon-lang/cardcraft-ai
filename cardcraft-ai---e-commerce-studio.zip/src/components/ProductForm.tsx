import React, { useRef } from 'react';
import {
  RotateCcw,
  Check,
  ShoppingBag,
  Store,
  ShoppingCart,
  Zap,
  Sliders,
  Sparkles,
  TrendingUp,
  Image as ImageIcon,
  UploadCloud,
  Layers,
} from 'lucide-react';
import { Marketplace, ToneOfVoice, ProductFormData } from '../types';
import { PRESETS } from '../data/presets';

interface ProductFormProps {
  formData: ProductFormData;
  onChange: (data: Partial<ProductFormData>) => void;
  onSubmit: () => void;
  isLoading: boolean;
  onSelectPreset: (presetId: string) => void;
}

export const ProductForm: React.FC<ProductFormProps> = ({
  formData,
  onChange,
  onSubmit,
  isLoading,
  onSelectPreset,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      const sizeMB = (file.size / (1024 * 1024)).toFixed(1);

      // Create image to get dimensions
      const img = new Image();
      img.onload = () => {
        onChange({
          imageFileName: file.name,
          imageFileSize: `${sizeMB} MB`,
          imageDimensions: `${img.width} × ${img.height}px`,
          imageDataUrl: dataUrl,
        });
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      const sizeMB = (file.size / (1024 * 1024)).toFixed(1);

      const img = new Image();
      img.onload = () => {
        onChange({
          imageFileName: file.name,
          imageFileSize: `${sizeMB} MB`,
          imageDimensions: `${img.width} × ${img.height}px`,
          imageDataUrl: dataUrl,
        });
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  const bulletCount = formData.features
    .split('\n')
    .filter((l) => l.trim().length > 0).length;

  const marketplaceGuidelines: Record<Marketplace, string> = {
    Amazon: 'US & EU Guidelines Loaded',
    Ozon: 'Ozon Rich-Content Ready',
    Wildberries: 'WB Algorithm Optimized',
    Shopify: 'D2C Schema & SEO Ready',
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="bg-white rounded-xl p-5 sm:p-6 border border-slate-200/90 shadow-sm">
        {/* Step Title Header */}
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-indigo-600 text-white text-xs flex items-center justify-center font-bold">
              1
            </span>
            <h2 className="font-display font-semibold text-base sm:text-lg text-slate-900">
              Product Information &amp; Assets
            </h2>
          </div>
          <button
            type="button"
            onClick={() => {
              if (formData.marketplace === 'Ozon') onSelectPreset('ozon-sample');
              else if (formData.marketplace === 'Wildberries') onSelectPreset('wildberries-sample');
              else if (formData.marketplace === 'Shopify') onSelectPreset('shopify-sample');
              else onSelectPreset('nomad-espresso');
            }}
            className="text-xs text-indigo-600 font-semibold flex items-center gap-1 hover:text-indigo-800 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Auto-Fill {formData.marketplace} Demo
          </button>
        </div>

        {/* Source Product Shot Dropzone */}
        <div className="mb-4">
          <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
            Source Product Shot
          </label>
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            className="relative bg-slate-50 border border-slate-200 rounded-xl p-3.5 transition-all hover:bg-slate-100/70"
          >
            <div className="flex items-center gap-3.5">
              <div className="relative w-20 h-20 rounded-lg overflow-hidden shrink-0 shadow-sm bg-slate-200 border border-slate-200">
                <img
                  src={formData.imageDataUrl}
                  alt="Product preview"
                  className="w-full h-full object-cover"
                />
                <span className="absolute bottom-1 right-1 bg-emerald-500 text-white rounded-full p-0.5 flex items-center justify-center shadow">
                  <Check className="w-3 h-3 stroke-[2.5]" />
                </span>
              </div>
              <div className="flex flex-col min-w-0 flex-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-xs sm:text-sm font-semibold text-slate-900 truncate">
                    {formData.imageFileName}
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-200 text-slate-700 font-medium">
                    {formData.imageFileSize}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Isolated white marble setup • {formData.imageDimensions}
                </p>
                <div className="flex items-center gap-3 mt-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1"
                  >
                    <UploadCloud className="w-3.5 h-3.5" /> Replace
                  </button>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-xs text-slate-600 hover:text-slate-900 flex items-center gap-1"
                  >
                    <ImageIcon className="w-3.5 h-3.5" /> Add Angles (2)
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileChange}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Target Marketplace Selector */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider flex items-center gap-1">
              Target Marketplace
            </label>
            <span className="text-xs text-emerald-600 font-semibold">
              {marketplaceGuidelines[formData.marketplace]}
            </span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
            {[
              { id: 'Amazon', label: 'Amazon', icon: ShoppingBag },
              { id: 'Ozon', label: 'Ozon', icon: Store },
              { id: 'Wildberries', label: 'Wildberries', icon: Layers },
              { id: 'Shopify', label: 'Shopify', icon: ShoppingCart },
            ].map((market) => {
              const Icon = market.icon;
              const isSelected = formData.marketplace === market.id;
              return (
                <button
                  key={market.id}
                  type="button"
                  onClick={() => onChange({ marketplace: market.id as Marketplace })}
                  className={`py-2 px-2 rounded-lg text-xs font-semibold flex flex-col items-center gap-1 transition-all border ${
                    isSelected
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{market.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Product Title Input */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">
              Product Title
            </label>
            <span
              className={`text-xs font-medium ${
                formData.title.length > 120 ? 'text-amber-600 font-bold' : 'text-slate-500'
              }`}
            >
              {formData.title.length} / 120 chars
            </span>
          </div>
          <input
            type="text"
            value={formData.title}
            onChange={(e) => onChange({ title: e.target.value })}
            placeholder="e.g. Portable Espresso Coffee Maker 18 Bar"
            className="w-full h-10 px-3.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-900 text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-medium"
          />
        </div>

        {/* Key Features Textarea */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">
              Key Features &amp; Selling Points
            </label>
            <span className="text-xs text-slate-500">
              {bulletCount} {bulletCount === 1 ? 'bullet' : 'bullets'} extracted
            </span>
          </div>
          <textarea
            rows={5}
            value={formData.features}
            onChange={(e) => onChange({ features: e.target.value })}
            placeholder="Enter key technical specs or selling highlights..."
            className="w-full p-3 rounded-lg bg-slate-50 border border-slate-200 text-slate-800 text-xs sm:text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all leading-relaxed font-sans"
          />
        </div>

        {/* Tone of Voice Selector */}
        <div className="mb-4">
          <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
            Tone of Voice
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
            {[
              'Premium & Luxury',
              'Selling & Energy',
              'Technical',
              'Minimalist',
            ].map((tone) => {
              const isSelected = formData.tone === tone;
              return (
                <button
                  key={tone}
                  type="button"
                  onClick={() => onChange({ tone: tone as ToneOfVoice })}
                  className={`py-2 px-1.5 text-center rounded-lg text-xs font-semibold transition-all border ${
                    isSelected
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
                  }`}
                >
                  {tone}
                </button>
              );
            })}
          </div>
        </div>

        {/* Advanced Options Accordion */}
        <div className="mb-5 p-3 rounded-lg bg-slate-50 border border-slate-200">
          <details className="group" open>
            <summary className="flex items-center justify-between cursor-pointer list-none text-xs font-semibold text-slate-800">
              <span className="flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-indigo-600" />
                Visual Style Preset &amp; Generation Rules
              </span>
              <span className="text-[10px] text-slate-500 group-open:rotate-180 transition-transform">
                ▼
              </span>
            </summary>
            <div className="pt-2.5 flex flex-wrap gap-1.5">
              {[
                { name: 'Modern Clean Architecture', dot: 'bg-indigo-600' },
                { name: 'High-Contrast Infographics', dot: 'bg-emerald-500' },
                { name: 'Warm Lifestyle Depth', dot: 'bg-amber-500' },
                { name: 'Bold Retail POP', dot: 'bg-rose-500' },
              ].map((preset) => {
                const isSelected = (formData.visualPreset || 'Modern Clean Architecture') === preset.name;
                return (
                  <button
                    key={preset.name}
                    type="button"
                    onClick={() => onChange({ visualPreset: preset.name })}
                    className={`px-2.5 py-1 rounded text-xs border transition-all flex items-center gap-1.5 font-medium cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-50 border-indigo-300 text-indigo-900 shadow-xs ring-1 ring-indigo-400'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${preset.dot}`}></span>
                    <span>{preset.name}</span>
                  </button>
                );
              })}
            </div>
          </details>
        </div>

        {/* Primary CTA Button */}
        <button
          type="button"
          onClick={onSubmit}
          disabled={isLoading}
          className="w-full py-3.5 px-6 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-display font-semibold text-sm sm:text-base shadow-md shadow-indigo-600/20 flex items-center justify-center gap-2 transition-all disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer group"
        >
          {isLoading ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Analyzing Image &amp; Synthesizing Kit...</span>
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 text-amber-300 fill-amber-300 transition-transform group-hover:scale-110" />
              <span>Generate Card &amp; Infographics</span>
              <span className="ml-auto text-xs bg-indigo-500/50 text-indigo-100 px-2.5 py-1 rounded-md font-semibold">
                1 Credit
              </span>
            </>
          )}
        </button>
      </div>

      {/* Algorithmic Match Score Card */}
      <div className="bg-white rounded-xl p-4 border border-slate-200/90 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200/80 flex items-center justify-center">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs sm:text-sm font-bold text-slate-900">
              Algorithmic Match Score
            </div>
            <div className="text-xs text-slate-500">
              Predicted CTR boost +24.8% on {formData.marketplace}
            </div>
          </div>
        </div>
        <div className="font-display font-bold text-xl sm:text-2xl text-emerald-600">
          98.4%
        </div>
      </div>
    </div>
  );
};
