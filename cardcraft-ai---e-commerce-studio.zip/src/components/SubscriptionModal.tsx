import React from 'react';
import { Check, Zap, X, Shield, Sparkles, CreditCard, ArrowRight } from 'lucide-react';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  credits: number;
  maxCredits: number;
  onAddCredits?: (amount: number) => void;
}

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({
  isOpen,
  onClose,
  credits,
  maxCredits,
  onAddCredits,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-5 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-sm">
              <Zap className="w-4 h-4 fill-white" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg text-slate-900">
                Subscription &amp; Credits
              </h3>
              <p className="text-xs text-slate-500">
                Manage your CardCraft AI plan and generation quota
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Active Plan Card */}
          <div className="p-5 rounded-xl bg-gradient-to-r from-indigo-50/70 to-slate-50 border border-indigo-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-indigo-600 text-white">
                  PRO MERCHANT
                </span>
                <span className="text-xs text-slate-500 font-medium">Active Subscription</span>
              </div>
              <div className="text-2xl font-bold text-slate-900">$49 <span className="text-xs font-normal text-slate-500">/ month • Renews Oct 1</span></div>
              <p className="text-xs text-slate-600 mt-1">
                Full access to Gemini 3.8 Flash, Multi-modal vision analysis, and Ozon/WB/Shopify algorithms.
              </p>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 text-center shrink-0 min-w-[140px] shadow-xs">
              <div className="text-[11px] text-slate-500 font-semibold uppercase tracking-wider">Credits Left</div>
              <div className="text-2xl font-black text-indigo-600">{credits}</div>
              <div className="text-[11px] text-slate-400">out of {maxCredits} monthly</div>
            </div>
          </div>

          {/* Features Included */}
          <div>
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3">
              Included in your Merchant Tier:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-slate-700">
              {[
                'Multi-Modal Visual Product Analysis',
                'Ozon Rich-Content Calibration',
                'Wildberries Algorithm CTR Tuning',
                'Amazon A+ Enhanced Story Creator',
                'Shopify D2C Schema & SEO Ready',
                'Clean 1-Click JSON Output Export',
              ].map((feat, i) => (
                <div key={i} className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </div>
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Credit Packs */}
          <div className="pt-2 border-t border-slate-100">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3 flex items-center justify-between">
              <span>Need More Generations?</span>
              <span className="text-[11px] text-slate-400 font-normal">Instant top-up</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => onAddCredits?.(50)}
                className="p-3.5 rounded-xl border border-slate-200 hover:border-indigo-500 hover:bg-indigo-50/30 text-left transition-all group flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-slate-900 text-xs sm:text-sm group-hover:text-indigo-600">
                    +50 Extra Credits
                  </div>
                  <div className="text-[11px] text-slate-500">$15 one-time</div>
                </div>
                <div className="px-2.5 py-1 rounded-lg bg-slate-100 group-hover:bg-indigo-600 group-hover:text-white text-xs font-semibold text-slate-700 transition-colors">
                  Add
                </div>
              </button>

              <button
                type="button"
                onClick={() => onAddCredits?.(200)}
                className="p-3.5 rounded-xl border border-slate-200 hover:border-indigo-500 hover:bg-indigo-50/30 text-left transition-all group flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-slate-900 text-xs sm:text-sm group-hover:text-indigo-600">
                    +200 Extra Credits
                  </div>
                  <div className="text-[11px] text-slate-500">$45 (Save 25%)</div>
                </div>
                <div className="px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 group-hover:bg-indigo-600 group-hover:text-white text-xs font-semibold transition-colors">
                  Add
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span className="flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-emerald-600" />
            Stripe Secure Billing
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors"
          >
            Back to Studio
          </button>
        </div>
      </div>
    </div>
  );
};
