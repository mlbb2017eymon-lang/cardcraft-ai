import React, { useState } from 'react';
import { Key, X, Check, Copy, ShieldCheck, Terminal, AlertCircle } from 'lucide-react';
import { copyToClipboard } from '../utils/clipboard';

interface ApiKeysModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApiKeysModal: React.FC<ApiKeysModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const copyCurl = async () => {
    await copyToClipboard(`curl -X POST https://ais-dev-qpas43wgkfbotza5dn6vb5-312966973728.asia-southeast1.run.app/api/marketing-kit \\
  -H "Content-Type: application/json" \\
  -d '{"title":"Espresso Machine","marketplace":"Amazon","tone":"Premium & Luxury"}'`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-5 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-sm">
              <Key className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg text-slate-900">
                API Keys &amp; Webhooks
              </h3>
              <p className="text-xs text-slate-500">
                Server-side endpoints and marketplace integrations
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold text-emerald-900">
                Secure Full-Stack AI Proxy Active
              </h4>
              <p className="text-xs text-emerald-700 mt-0.5">
                Gemini API calls are processed securely server-side through <code className="font-mono bg-emerald-100/60 px-1 py-0.5 rounded text-[11px]">/api/marketing-kit</code> without exposing credentials to client browsers.
              </p>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-indigo-600" />
                Direct API Integration (cURL)
              </label>
              <button
                type="button"
                onClick={copyCurl}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied command!' : 'Copy cURL'}</span>
              </button>
            </div>

            <div className="p-3 bg-slate-950 text-slate-200 rounded-xl font-mono text-xs overflow-x-auto">
              <pre className="text-emerald-400">
{`POST /api/marketing-kit
Content-Type: application/json

{
  "title": "NomadBrew Pro Portable Espresso",
  "marketplace": "Amazon",
  "tone": "Premium & Luxury"
}`}
              </pre>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-600">
            <div className="p-3 rounded-lg border border-slate-200 bg-slate-50">
              <span className="font-bold text-slate-800 block mb-1">Ozon Seller API</span>
              <span>Direct rich-content JSON injection enabled.</span>
            </div>
            <div className="p-3 rounded-lg border border-slate-200 bg-slate-50">
              <span className="font-bold text-slate-800 block mb-1">Wildberries WB Partner</span>
              <span>Card title and keywords auto-feed ready.</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
