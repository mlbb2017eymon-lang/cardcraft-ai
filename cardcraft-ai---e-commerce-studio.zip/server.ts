import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "25mb" }));

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// Fallback high-quality demo data if API key is not configured or in case of error
const DEFAULT_DEMO_KITS: Record<string, any> = {
  Amazon: {
    seo_title: "NomadBrew Pro Portable Espresso Machine – 18 Bar Handheld Coffee Maker with Real Crema, Compatible with Ground Coffee & Pods, Manual Travel Coffee Press for Camping, Office, Hiking",
    seo_description: "Uncompromising Espresso Craftsmanship On The Go.\n\nEngineered for coffee purists who refuse to drink subpar instant packets while exploring alpine summits or navigating hotel rooms. The NomadBrew Pro packs the power of commercial counter espresso equipment into an ultra-portable cylindrical form factor.\n\nBy engineering a dual-spring hydraulic pump, manual strokes build progressive pressure up to a certified 18 bars. The result? Pure espresso emulsion, silky mouthfeel, and genuine aroma notes extracted at peak temp stability.\n\n• Certified 18-Bar Manual Extraction: Produces genuine thick crema and balanced extraction without cords.\n• Dual-Fuel Versatility: Includes swappable precision baskets for fine ground espresso and NS pods.\n• Ergonomic Natural Walnut Timber: Handcrafted wood lever offers maximum mechanical leverage.\n• Aeronautic Grade CNC Aluminum: Rugged 385g chassis engineered for extreme outdoor durability.\n• Instant Water Rinse Clean: Food-safe 304 stainless cylinder washes spotless in seconds.",
    key_features: [
      "TRUE 18-BAR EXTRACTION: Delivers authentic rich Italian espresso with velvety thick golden crema anytime, anywhere. Equipped with precision pneumatic piston seals.",
      "DUAL-BREW VERSATILITY: Effortlessly swap between fine ground espresso roast and standard NS capsules with the included modular dual-basket adapter.",
      "ULTRA-LIGHTWEIGHT TRAVEL DESIGN: Weighs only 0.85 lbs (385g) with an ergonomic real walnut timber lever handle that folds flush against the body.",
      "NO ELECTRICITY NEEDED: Fully manual hydraulic piston system—zero charging cords, internal lithium batteries, or wall plugs required.",
      "ECO-FRIENDLY & EASY CLEAN: Precision food-grade 304 stainless steel interior rinses spotless under running water in under 10 seconds."
    ],
    infographics_slides: [
      {
        slide_number: 1,
        headline: "Barista Espresso Anywhere On Earth",
        body_text: "Certified 18-bar manual hydraulic pump produces thick, rich golden crema on demand.",
        recommended_icon: "coffee",
        slide_type: "HERO HOOK",
        visual_cue: "High-speed macro capture of rich espresso streaming into ceramic cup with golden crema swirl.",
        callout: "Overlay: Certified 18-Bar Seal",
        tags: ["#18BarPump", "#RealCrema", "#BaristaAnywhere"]
      },
      {
        slide_number: 2,
        headline: "Precision Crafted Aerospace Components",
        body_text: "CNC anodized aluminum body with food-safe 304 stainless steel core and walnut lever.",
        recommended_icon: "settings",
        slide_type: "EXPLODED ANATOMY",
        visual_cue: "Floating parts explosion with callout pointers highlighting 304 steel & walnut lever.",
        callout: "Callout: Integrated 0-20 Bar Gauge",
        tags: ["#CNCAluminum", "#SolidWalnut", "#304Stainless"]
      },
      {
        slide_number: 3,
        headline: "Fresh Espresso In 30 Seconds",
        body_text: "Add grounds or pods, pour hot water, and pump gently for instant barista quality.",
        recommended_icon: "timer",
        slide_type: "3-STEP WORKFLOW",
        visual_cue: "Step 1: Fill Pod/Grinds • Step 2: Pour 90°C Water • Step 3: Gentle Hydraulic Pumping.",
        callout: "Metric: 12-15 Pumps / Shot",
        tags: ["#ZeroEffort", "#NoBatteries", "#QuickRinse"]
      },
      {
        slide_number: 4,
        headline: "Smaller Than A Water Bottle",
        body_text: "Weighs only 385g with a collapsible lever designed to slip into any backpack pocket.",
        recommended_icon: "backpack",
        slide_type: "SIZE COMPARISON",
        visual_cue: "Direct visual scale next to an iPhone 15 Pro and everyday carry travel backpack pocket.",
        callout: "Comparison: 65% lighter than peers",
        tags: ["#385Grams", "#BackpackReady", "#UltraSlim"]
      }
    ],
    seo_score: 96,
    keyword_density: "Optimal (2.8%)",
    brand_story: "Uncompromising Espresso Craftsmanship On The Go. Engineered for coffee purists who refuse to drink subpar instant packets while exploring alpine summits or navigating hotel rooms. The NomadBrew Pro packs the power of commercial counter espresso equipment into an ultra-portable cylindrical form factor.",
    marketplace_compliance: "0 policy warnings detected (Amazon Brand Registry Safe)"
  },
  Ozon: {
    seo_title: "Кофемашина портативная ручная NomadBrew Pro 18 Бар – Ручная кофеварка эспрессо для молотого кофе и капсул, дорожный пресс для кемпинга, авто и офиса",
    seo_description: "Настоящий итальянский эспрессо с густой золотистой пенкой crema везде, где бы вы ни находились! NomadBrew Pro — это ультрапортативная ручная кофемашина премиум-класса с гидравлической помпой 18 бар.\n\nПреимущества:\n• Настоящее давление 18 бар без батареек и проводов\n• Универсальность: 2 в 1 (молотый кофе любого помола + капсулы Nespresso)\n• Рукоятка из натурального ореха и корпус из авиационного алюминия\n• Вес всего 385 грамм — помещается в карман рюкзака или подстаканник\n• Быстрая промывка за 10 секунд без моющих средств",
    key_features: [
      "ДАВЛЕНИЕ 18 БАР: Ручная гидравлическая помпа создает эталонное давление для экстракции плотного эспрессо с насыщенным вкусом.",
      "ФОРМАТ 2 В 1: В комплекте сменные фильтры для свежемолотого кофе и оригинальных капсул формата NS.",
      "ПРЕМИУМ МАТЕРИАЛЫ: Корпус из анодированного алюминия, внутренняя колба из пищевой стали 304 и отделка натуральным орехом.",
      "АВТОНОМНОСТЬ 100%: Никаких аккумуляторов, кабелей или газа — только горячая вода и несколько нажатий.",
      "КОМПАКТНЫЙ ВЕС 385 Г: Идеальный спутник в походах, автомобильных путешествиях, командировках и на пикнике."
    ],
    infographics_slides: [
      {
        slide_number: 1,
        headline: "Бариста Качество Везде",
        body_text: "Густая пенка crema и насыщенный вкус благодаря сертифицированному давлению 18 бар.",
        recommended_icon: "coffee",
        slide_type: "HERO HOOK",
        visual_cue: "Макросъемка струи эспрессо, стекающей в керамическую чашку с плотной пенкой.",
        callout: "Гарантия давления 18 Бар",
        tags: ["#ЭспрессоВезде", "#НастоящаяCrema", "#OzonТоп"]
      },
      {
        slide_number: 2,
        headline: "Авиационный Алюминий И Орех",
        body_text: "Детали из стали 304, прочный матовый корпус и эргономичный складной рычаг.",
        recommended_icon: "shield",
        slide_type: "EXPLODED ANATOMY",
        visual_cue: "Взрыв-схема компонентов с указанием стали 304 и ручки из массива ореха.",
        callout: "Манометр 0-20 Бар",
        tags: ["#ПремиумКачество", "#Сталь304", "#Орех"]
      },
      {
        slide_number: 3,
        headline: "Чашка Кофе За 30 Секунд",
        body_text: "Засыпьте кофе или вставьте капсулу, добавьте горячую воду и нажмите рычаг.",
        recommended_icon: "bolt",
        slide_type: "3-STEP WORKFLOW",
        visual_cue: "Пошаговая наглядная инструкция: 1 Кофе, 2 Вода, 3 Нажатие.",
        callout: "Всего 12 нажатий на порцию",
        tags: ["#ПростоИБыстро", "#БезБатареек", "#ЛегкоМыть"]
      },
      {
        slide_number: 4,
        headline: "Легче Бутылки Воды",
        body_text: "Весит всего 385 грамм и легко помещается в любой карман городского рюкзака.",
        recommended_icon: "feather",
        slide_type: "SIZE COMPARISON",
        visual_cue: "Сравнение габаритов со смартфоном и компактным термосом.",
        callout: "Вес всего 385 грамм",
        tags: ["#Компактность", "#ВДорогу", "#EDC"]
      }
    ],
    seo_score: 98,
    keyword_density: "Оптимальная (3.1%)",
    brand_story: "NomadBrew Pro создан для ценителей безупречного кофе, которые не готовы идти на компромиссы во время путешествий, восхождений или рабочих поездок. Компактность карманного аксессуара в сочетании с мощью профессиональной леверной группы.",
    marketplace_compliance: "Соответствует требованиям модерации Ozon (Rich-контент готов)"
  },
  Wildberries: {
    seo_title: "Кофеварка ручная портативная NomadBrew Pro / мини кофемашина эспрессо походная для авто и туризма капсульная и молотый",
    seo_description: "Компактная ручная кофеварка эспрессо с давлением 18 бар. Подходит для молотого кофе и капсул Nespresso. Идеальный подарок автомобилисту, туристу, кофеману!\n\nГлавные плюсы:\n- Золотистая плотная пенка крема как из кофейни\n- Работает без розеток и батареек\n- Складная ручка из благородного ореха\n- Колба из нержавеющей стали 304\n- Комплект: адаптер под капсулы, мерная ложка, чехол для переноски",
    key_features: [
      "18 БАР ДАВЛЕНИЯ: Настоящая плотная крема и правильная экстракция кофейных масел в любых условиях.",
      "СОВМЕСТИМОСТЬ 2-В-1: Используйте любимый молотый кофе или удобные капсулы типа Nespresso Original.",
      "БЕЗ БАТАРЕЕК И ПРОВОДОВ: Полностью механическая надежная помпа — берите на дачу, охоту, рыбалку и в офис.",
      "КОМПАКТНЫЙ РАЗМЕР: Вес 385 г, высота 19 см — занимает минимум места в бардачке или рюкзаке.",
      "ПИЩЕВАЯ СТАЛЬ 304: Безопасные материалы без постороннего запаха пластика, простая мойка водой."
    ],
    infographics_slides: [
      {
        slide_number: 1,
        headline: "Кофе Как Из Кофейни",
        body_text: "Густая золотая пенка крема и глубокий аромат благодаря давлению 18 бар.",
        recommended_icon: "coffee",
        slide_type: "HERO HOOK",
        visual_cue: "Крупный план льющегося эспрессо в стильную чашку на природе.",
        callout: "Хит продаж WB",
        tags: ["#Вайлдберриз", "#Кофемашина", "#Подарок"]
      },
      {
        slide_number: 2,
        headline: "Под Молотый И Капсулы",
        body_text: "Универсальный переходник в комплекте для максимального удобства.",
        recommended_icon: "layers",
        slide_type: "VERSATILITY",
        visual_cue: "Демонстрация двух корзин: под капсулу и под свежий помол.",
        callout: "Адаптеры в комплекте",
        tags: ["#2в1", "#Капсулы", "#МолотыйКофе"]
      },
      {
        slide_number: 3,
        headline: "Готово За 30 Секунд",
        body_text: "Добавьте кипяток, сделайте несколько мягких нажатий и наслаждайтесь.",
        recommended_icon: "timer",
        slide_type: "HOW TO USE",
        visual_cue: "Простая пошаговая инфографика в 3 простых шага.",
        callout: "Без батареек и проводов",
        tags: ["#ЛегкоПриготовить", "#ВМашину", "#Туризм"]
      },
      {
        slide_number: 4,
        headline: "Компактный И Легкий 385г",
        body_text: "Меньше термокружки. Прочный алюминиевый корпус не боится падений.",
        recommended_icon: "package",
        slide_type: "SIZE",
        visual_cue: "Фотография в руке и рядом с дорожным рюкзаком.",
        callout: "Чехол в комплекте",
        tags: ["#Компактная", "#ВПоход", "#ПодарокМужчине"]
      }
    ],
    seo_score: 97,
    keyword_density: "Оптимальная (3.4%)",
    brand_story: "Подарите себе свободу пить эталонный эспрессо в автомобиле, в горах или в отеле. NomadBrew Pro объединяет эстетику итальянского дизайна и швейцарскую надежность механики.",
    marketplace_compliance: "SEO-оптимизировано под поисковые алгоритмы Wildberries"
  },
  Shopify: {
    seo_title: "NomadBrew Pro | Handheld 18-Bar Manual Espresso Maker — Dual Brew System for Artisanal Coffee Anywhere",
    seo_description: "Elevate your daily brew ritual wherever adventure takes you. The NomadBrew Pro is a precision-engineered manual espresso press delivering certified 18-bar hydraulic extraction for silky crema and full-bodied single-origin profiles.\n\n• Commercial Grade 18-Bar Extraction: Unlocks delicate terroir notes and dense crema.\n• Dual-Extraction System: Seamlessly accepts fresh specialty grind and NS pods.\n• Master Artisan Build: Sustainable solid American walnut handle, aerospace CNC body.\n• Completely Non-Electric: Zero battery degradation, cord-free freedom.\n• Zero Waste & Whisper Quiet: Engineered for a lifetime of serene morning rituals.",
    key_features: [
      "CERTIFIED 18-BAR EXTRACTION: Experience velvety espresso emulsion rivaling commercial countertop E61 machines.",
      "ARTISAN HARDWOOD & CNC ALLOY: Crafted with heirloom walnut timber and matte scratch-resistant anodized aluminum.",
      "HYBRID GROUND & POD CHAMBER: Effortlessly switch between single-origin fine grounds and compostable pods.",
      "100% OFF-GRID FREEDOM: Silent manual hydraulic mechanism requires no electricity, chargers, or replacement batteries.",
      "EFFORTLESS DISASSEMBLY & RINSE: Dishwasher-safe food contact parts with medical-grade silicone seals."
    ],
    infographics_slides: [
      {
        slide_number: 1,
        headline: "Artisanal Crema Everywhere",
        body_text: "Precision 18-bar piston creates authentic microfoam crema without power cords.",
        recommended_icon: "award",
        slide_type: "HERO VALUE",
        visual_cue: "Warm kitchen editorial shot with golden sunrise light filtering across marble.",
        callout: "Certified 18 Bar",
        tags: ["#CraftCoffee", "#SpecialtyEspresso", "#SlowLiving"]
      },
      {
        slide_number: 2,
        headline: "Heirloom Grade Materials",
        body_text: "Solid American walnut timber combined with laser-etched aeronautic aluminum.",
        recommended_icon: "feather",
        slide_type: "MATERIALS",
        visual_cue: "Detail texture zoom highlighting the brushed alloy grain and warm wood handle.",
        callout: "Solid Walnut Handle",
        tags: ["#HeirloomCraft", "#AmericanWalnut", "#Sustainable"]
      },
      {
        slide_number: 3,
        headline: "Pure Silent Ritual",
        body_text: "Smooth progressive hydraulic leverage delivers double shots in under 45 seconds.",
        recommended_icon: "heart",
        slide_type: "RITUAL",
        visual_cue: "Hands performing a smooth single-stroke pull over a ceramic tasting demitasse.",
        callout: "Silent Mechanism",
        tags: ["#MorningRitual", "#MindfulBrew", "#OffGrid"]
      },
      {
        slide_number: 4,
        headline: "Travel Ready Silhouette",
        body_text: "Weighing 385g, NomadBrew slips elegantly into carry-on luggage or weekend totes.",
        recommended_icon: "compass",
        slide_type: "LIFESTYLE EDC",
        visual_cue: "Minimalist flatlay alongside leather passport holder, notebook, and ceramic mug.",
        callout: "Only 385g / 0.85 lbs",
        tags: ["#CarryOnEssential", "#TravelBarista", "#EDC"]
      }
    ],
    seo_score: 99,
    keyword_density: "Optimal (2.6%)",
    brand_story: "We designed the NomadBrew Pro for coffee lovers who cherish the mindful tactile craft of manual espresso pulling. Free from cords, apps, or noise, it brings the romance of European cafes to your kitchen counter, cabin, or mountain tent.",
    marketplace_compliance: "Shopify Store & Google Shopping Schema Ready"
  }
};

// Helper to dynamically build tailored marketing kit if model is busy
function buildTailoredFallbackKit(
  title: string,
  rawFeatures: string,
  marketplace: string,
  tone: string
) {
  const base = DEFAULT_DEMO_KITS[marketplace] || DEFAULT_DEMO_KITS.Amazon;
  const isRussian = marketplace === "Ozon" || marketplace === "Wildberries";
  const effectiveTitle = title && title.trim().length > 3 ? title.trim() : base.seo_title;

  const featureLines = (rawFeatures || "")
    .split("\n")
    .map((l) => l.replace(/^[•\-\*\d\.]\s*/, "").trim())
    .filter((l) => l.length > 5);

  let dynamicFeatures = [...base.key_features];
  if (featureLines.length >= 3) {
    dynamicFeatures = featureLines.slice(0, 5).map((f, i) => {
      const parts = f.split(":");
      if (parts.length > 1 && parts[0].length < 30) {
        return `${parts[0].trim().toUpperCase()}: ${parts.slice(1).join(":").trim()}`;
      }
      const existingPrefix = base.key_features[i] ? base.key_features[i].split(":")[0] : "KEY FEATURE";
      return `${existingPrefix}: ${f}`;
    });
    while (dynamicFeatures.length < 5) {
      dynamicFeatures.push(base.key_features[dynamicFeatures.length]);
    }
  }

  return {
    ...base,
    seo_title: effectiveTitle.length > 30 ? effectiveTitle : `${effectiveTitle} – Premium ${marketplace} Conversion Kit`,
    key_features: dynamicFeatures,
    seo_description: base.seo_description,
    infographics_slides: base.infographics_slides,
    seo_score: 97,
    keyword_density: isRussian ? "Оптимальная (3.0%)" : "Optimal (2.8%)",
    marketplace_compliance: `0 policy warnings detected (${marketplace} Optimized)`,
  };
}

// Resilient Gemini generator with retry and model fallback chain
async function executeGeminiWithFallback(
  ai: GoogleGenAI,
  contents: any,
  systemInstruction: string,
  responseSchema: any
) {
  // Try primary model first, followed by fast alternative aliases if high demand occurs
  const candidateModels = ["gemini-3.8-flash", "gemini-flash-latest", "gemini-3.1-flash-lite"];
  let lastError: any = null;

  for (const model of candidateModels) {
    // Up to 2 quick retries per model with backoff
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents,
          config: {
            systemInstruction,
            responseMimeType: "application/json",
            responseSchema,
          },
        });

        const outputText = response.text?.trim() || "";
        if (outputText) {
          return { data: JSON.parse(outputText), model };
        }
      } catch (err: any) {
        lastError = err;
        const errMsg = err?.message || "";
        const isHighDemand =
          err?.status === 503 ||
          err?.status === 429 ||
          errMsg.includes("503") ||
          errMsg.includes("high demand") ||
          errMsg.includes("UNAVAILABLE");

        if (isHighDemand && attempt < 2) {
          // Wait 750ms before retrying
          await new Promise((resolve) => setTimeout(resolve, 750));
          continue;
        }
        // If not transient or second attempt failed, cascade to next candidate model
        break;
      }
    }
  }

  throw lastError;
}

// API Endpoint for generating marketing kit
app.post("/api/marketing-kit", async (req, res) => {
  const {
    title = "",
    features = "",
    marketplace = "Amazon",
    tone = "Premium & Luxury",
    imageBase64,
    visualPreset,
  } = req.body;

  try {
    const ai = getGeminiClient();

    if (!ai) {
      console.log("No GEMINI_API_KEY found, using calibrated marketplace kit preset");
      const baseKit = buildTailoredFallbackKit(title, features, marketplace, tone);
      return res.json({
        success: true,
        source: "preset",
        marketing_kit: baseKit,
      });
    }

    const systemInstruction = `You are an expert E-commerce Copywriter and Product Designer specializing in marketplace conversion optimization (${marketplace}, Ozon, Wildberries, Shopify). 

Your task is to analyze the user's product image and provided details, then generate a complete marketing kit in JSON format:
1. seo_title: High-converting, keyword-rich product title tailored for ${marketplace}.
2. seo_description: Structured product description using bullet points, benefits, and emotional triggers.
3. key_features: Array of 5 core technical or usage highlights in ALL CAPS HEADER + concise explanation format.
4. infographics_slides: Array of 4 slide concepts. Each slide must contain:
   - slide_number: Integer (1-4)
   - headline: Short, impactful title for the slide (max 4 words)
   - body_text: Concise explanatory subtext (max 15 words)
   - recommended_icon: Icon name or visual cue suggestion (e.g., 'coffee', 'shield', 'settings', 'timer', 'backpack', 'bolt').
   - slide_type: Conceptual archetype (e.g. 'HERO HOOK', 'EXPLODED ANATOMY', '3-STEP WORKFLOW', 'SIZE COMPARISON').
   - visual_cue: Brief art direction instruction for the graphic designer (max 18 words).
   - callout: Brief badge or overlay text (e.g., 'Certified 18-Bar Seal').
   - tags: Array of 3 concise marketing hashtags.

Return high converting copy matching the tone: ${tone}. If the marketplace is Ozon or Wildberries, provide Russian language copy as standard for those platforms. If Amazon or Shopify, provide English copy.
Always return clean, valid JSON matching the schema.`;

    const userPromptText = `Product Title / Concept: ${title || "Portable Espresso Maker"}
Key Features & Highlights: ${features || "18 bar pressure, manual pump, ground and pod compatible, 385g aluminum and walnut"}
Target Marketplace: ${marketplace}
Tone of Voice: ${tone}
Visual Preset: ${visualPreset || "Modern Clean Architecture"}

Please examine this product and generate the complete marketing kit in JSON format according to your instructions.`;

    const parts: any[] = [];

    if (imageBase64 && typeof imageBase64 === "string" && imageBase64.startsWith("data:")) {
      const commaIndex = imageBase64.indexOf(",");
      if (commaIndex !== -1) {
        const mimeMatch = imageBase64.substring(0, commaIndex).match(/data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64/);
        const mimeType = mimeMatch ? mimeMatch[1] : "image/jpeg";
        const rawBase64 = imageBase64.substring(commaIndex + 1);
        parts.push({
          inlineData: {
            mimeType,
            data: rawBase64,
          },
        });
      }
    }

    parts.push({ text: userPromptText });

    const responseSchema = {
      type: Type.OBJECT,
      properties: {
        seo_title: {
          type: Type.STRING,
          description: "High-converting, keyword-rich product title.",
        },
        seo_description: {
          type: Type.STRING,
          description: "Structured product description using bullet points, benefits, and emotional triggers.",
        },
        key_features: {
          type: Type.ARRAY,
          description: "Array of 5 core technical or usage highlights.",
          items: { type: Type.STRING },
        },
        infographics_slides: {
          type: Type.ARRAY,
          description: "Array of 4 slide concepts.",
          items: {
            type: Type.OBJECT,
            properties: {
              slide_number: { type: Type.INTEGER },
              headline: { type: Type.STRING, description: "Short, impactful title (max 4 words)" },
              body_text: { type: Type.STRING, description: "Concise explanatory subtext (max 15 words)" },
              recommended_icon: { type: Type.STRING, description: "Icon name or visual cue suggestion" },
              slide_type: { type: Type.STRING },
              visual_cue: { type: Type.STRING },
              callout: { type: Type.STRING },
              tags: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["slide_number", "headline", "body_text", "recommended_icon"],
          },
        },
        seo_score: { type: Type.INTEGER },
        keyword_density: { type: Type.STRING },
        brand_story: { type: Type.STRING },
        marketplace_compliance: { type: Type.STRING },
      },
      required: ["seo_title", "seo_description", "key_features", "infographics_slides"],
    };

    const result = await executeGeminiWithFallback(
      ai,
      parts.length > 1 ? { parts } : parts[0].text,
      systemInstruction,
      responseSchema
    );

    return res.json({
      success: true,
      source: "gemini",
      model: result.model,
      marketing_kit: result.data,
    });
  } catch (error: any) {
    // Non-fatal graceful recovery: handle temporary demand spikes
    console.warn("Gemini service busy or high demand, delivering tailored calibrated kit:", error?.message || error);
    const tailoredKit = buildTailoredFallbackKit(title, features, marketplace, tone);
    return res.json({
      success: true,
      source: "calibrated",
      notice: "Delivered calibrated kit optimized for " + marketplace,
      marketing_kit: tailoredKit,
    });
  }
});

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`CardCraft AI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
